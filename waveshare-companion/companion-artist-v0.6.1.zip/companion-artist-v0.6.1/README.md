# Waveshare Companion v0.6.1 — Spotify-Künstler-Browse

Kompatibles, rücksetzbares Update für das bestehende Volumio-Backend v0.6.0.

## Ursache in v0.6.0

Die Meldung „nicht genügend verschiedene Titel gefunden“ kommt aus
`spotify_artist_preview()`, wenn nach Filterung **weniger als zwei verschiedene**
Songs übrig bleiben. Der alte Code verwirft Suche vollständig, sobald beim Browse
*irgendeine* Track-Zeile gefunden wird, und verwirft außerdem Metadatenarme
Spotify-Tracks selbst bei verifizierter Künstler-/Album-Herkunft.

**Ohne Zugriff auf den realen Volumio-REST-Body ist nicht bewiesen, welcher dieser
Fälle auf deinem Plugin 4.5.0 eintritt.** Das Diagnoseprogramm macht ihn sichtbar.

## Fix

- Fügt Browse-Ergebnisse und exakt passende Search-Treffer zusammen.
- Akzeptiert Spotify-Track-URI als Provenienz, auch ohne optionales `service`.
- Ein leerer `artist`-Wert wird ausschließlich in einem durch eindeutigen
  Artist-Knoten bestätigten Album-/Künstler-Browse-Pfad ergänzt. Globale
  Suchtreffer, Playlists und verwandte Künstler erben den Namen **nicht**.
- Verarbeitet auch `navigation.items` und einfache `items`-Antworten.
- Folgt bis zu 24 lesenden Spotify-Browse-Anfragen, darunter Playlist-Knoten.
- Gibt in `GET /api/volumio/spotify/artist/preview` zusätzlich ein optionales,
  rückwärtskompatibles `diagnostics`-Objekt mit Zählern aus.
- Keine Änderungen an `app.py`, `pipeline.py`, dem WAV-Protokoll oder dem
  Display-API-Vertrag. Bestehende API-Version bleibt v0.6.0.

## Installation

```bash
cd /srv/ai/projects
unzip -oq companion-artist-v0.6.1.zip
bash companion-artist-v0.6.1/install.sh /srv/ai/projects/companion-mvp/server
```

Der Installer sichert `volumio_controller.py`, startet systemd neu und rollt
bei fehlgeschlagener Readiness-Prüfung zurück.

## Ohne Wiedergabe testen

```bash
/srv/ai/projects/companion-mvp/server/.venv/bin/python \
  /srv/ai/projects/companion-artist-v0.6.1/diagnose_artist.py 'Daft Punk'
```

Der Test verwendet **nur GET** auf Volumio. Er gibt Anzahl gefundener
Artist-Knoten, Browse-Anfragen, Tracks, verworfene Interpreten und die
verschiedenen Songs aus. Falls noch weniger als zwei Titel ermittelt werden,
bitte die Ausgabe teilen; dann ist die tatsächliche URI-Form von Plugin 4.5.0
ersichtlich, ohne unsichere Vermutungen über die Wiedergabe zu treffen.

## API-Differenz

`GET /api/volumio/spotify/artist/preview?artist=Daft%20Punk&limit=20`
behält alle bisherigen Felder. Neu ist das optionale Feld:

```json
{
  "diagnostics": {
    "artist_nodes": 1,
    "search_items": 25,
    "browse_requests": 3,
    "browse_items": 60,
    "browse_errors": 0,
    "browse_tracks": 40,
    "search_tracks": 12,
    "rejected_other_artist": 3,
    "rejected_missing_artist": 0,
    "distinct_tracks": 20
  }
}
```

Zahlen sind Beispieldaten. Das Frontend darf `diagnostics` ignorieren.
Kein Auto-Play bei 0/1 Titel, keine Song-URI in Auswahl-IDs.

## Tests

Die bisherigen 59 automatisierten Tests und sechs zusätzliche Regressionstests
laufen mit simuliertem Volumio ohne Netzwerkzugriff. Auf deinem echten Gerät
steht die Prüfung noch aus.
