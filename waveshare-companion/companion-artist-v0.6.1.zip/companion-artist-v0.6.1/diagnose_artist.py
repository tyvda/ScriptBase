#!/usr/bin/env python3
"""Volumio artist inspection; read-only GET operations, no playback changes."""
from __future__ import annotations
import argparse
import json
import os
import sys
from pathlib import Path

parser=argparse.ArgumentParser(description='Spotify/Volumio artist browse diagnosis (GET only)')
parser.add_argument('artist',nargs='?',default='Daft Punk')
parser.add_argument('--url',default=os.getenv('VOLUMIO_URL','http://192.168.2.241'))
parser.add_argument('--verbose',action='store_true')
args=parser.parse_args()
sys.path.insert(0,str(Path(__file__).resolve().parent))
from volumio_controller import VolumioClient,VolumioError,ARTIST_PREVIEW_REV

client=VolumioClient(args.url)
print('Kuenstler-Diagnose',ARTIST_PREVIEW_REV,'URL:',client.base_url, 'Kuenstler:',repr(args.artist))
try:
    items=client._spotify_search_items(args.artist)
    print('Search-Elemente:',len(items))
    for item in items[:30]:
        uri=item.get('uri','')
        typ=str(item.get('type') or '')
        artist=str(item.get('artist') or '')
        name=str(item.get('title') or item.get('name') or '')
        if uri.startswith('spotify:artist:') or (args.verbose and uri.startswith('spotify:')):
            print('  Suche:','Typ',typ,'Service',item.get('service',''),
                  'Name',repr(name),'Artist',repr(artist),'URI',uri[:130])
    preview=client.spotify_artist_preview(args.artist)
    print('Quelle:',preview.get('source'),'bereit:',preview.get('ready_to_play',False),
          'Anzahl:',preview.get('count'), 'teilweise:',preview.get('partial_results'))
    print('Diagnose:',json.dumps(preview.get('diagnostics',{}),ensure_ascii=False,sort_keys=True))
    for i,t in enumerate(preview.get('tracks',[])[:20],1):
        print(f'{i:02d}. {t.get("title","")} — {t.get("artist","")}')
    if not preview.get('ready_to_play'):
        print('HINWEIS: Keine Wiedergabe veraendert. Bitte diese Ausgabe zur Fehlersuche senden.')
except (VolumioError,ValueError) as e:
    print('Volumio-Fehler:',str(e),file=sys.stderr)
    sys.exit(1)
