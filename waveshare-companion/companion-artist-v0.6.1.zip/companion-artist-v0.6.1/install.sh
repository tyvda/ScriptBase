#!/usr/bin/env bash
# Incremental controller-only upgrade; no changes to app.py or audio processing.
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
TARGET="${1:-/srv/ai/projects/companion-mvp/server}"
SERVICE=waveshare-companion.service
if [[ ! -f "$TARGET/volumio_controller.py" || ! -x "$TARGET/.venv/bin/python" ]]; then
  echo "Bestehender Controller oder Python-Venv fehlt: $TARGET" >&2; exit 2
fi
if ! systemctl --user cat "$SERVICE" >/dev/null 2>&1; then
  echo "Systemd-User-Service fehlt: $SERVICE" >&2; exit 2
fi
"$TARGET/.venv/bin/python" -m py_compile "$HERE/volumio_controller.py"
PYTHONPATH="$HERE" "$TARGET/.venv/bin/python" - <<'PY'
from volumio_controller import ARTIST_PREVIEW_REV, VolumioClient
assert ARTIST_PREVIEW_REV == '0.6.1'
assert hasattr(VolumioClient, '_navigation_items')
PY
BACKUP="$TARGET/volumio_controller.py.bak-artist-v061-$(date -u +%Y%m%d-%H%M%S)-$$"
cp -p -- "$TARGET/volumio_controller.py" "$BACKUP"
restore() {
  local rc=$?
  trap - ERR
  echo "Upgrade fehlgeschlagen, stelle Backup wieder her: $BACKUP" >&2
  cp -p -- "$BACKUP" "$TARGET/volumio_controller.py"
  systemctl --user restart "$SERVICE" || true
  exit "$rc"
}
trap restore ERR
install -m 0644 -- "$HERE/volumio_controller.py" "$TARGET/volumio_controller.py"
systemctl --user restart "$SERVICE"
healthy=0
for _ in $(seq 1 20); do
  if systemctl --user is-active --quiet "$SERVICE" && \
     curl -fsS --max-time 2 http://127.0.0.1:8000/api/volumio/v06/capabilities | \
     "$TARGET/.venv/bin/python" -c 'import json,sys;d=json.load(sys.stdin);assert d.get("volumio_enabled")' 2>/dev/null; then
    healthy=1; break
  fi
  sleep 1
done
if ((healthy != 1)); then
  echo "Systemdienst/Volumio-API nicht bereit; Rollback" >&2
  false
fi
trap - ERR
echo "Kuenstler-Browse v0.6.1 installiert; Backup: $BACKUP"
echo "Diagnose: $TARGET/.venv/bin/python $HERE/diagnose_artist.py 'Daft Punk'"
