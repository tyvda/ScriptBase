"""Volumio 4.5 artist browse regressions: all playback is mocked."""
from __future__ import annotations
import json
import unittest
import httpx
from volumio_controller import VolumioClient


def row(title, artist=None, *, uri=None, service=None, kind='song'):
    item={'title':title,'uri':uri or 'spotify:track:'+title.replace(' ','_'),'type':kind}
    if artist is not None: item['artist']=artist
    if service is not None: item['service']=service
    return item


def nav(*items):
    return {'navigation': {'lists': [{'items': list(items)}]}}


class ArtistFixTests(unittest.TestCase):
    def client(self, handler):
        return VolumioClient('http://192.168.2.241',transport=httpx.MockTransport(handler))

    def test_album_browse_missing_optional_artist_and_service(self):
        def handler(req):
            if req.url.path.endswith('/search'):
                return httpx.Response(200,json=nav(row('Daft Punk',uri='spotify:artist:real',kind='folder')))
            if req.url.path.endswith('/browse'):
                uri=req.url.params.get('uri')
                if uri=='spotify:artist:real':
                    return httpx.Response(200,json=nav(row('Discovery',uri='spotify:album:disc',kind='folder')))
                if uri=='spotify:album:disc':
                    # Artist+service omitted, but the verified artist album
                    # browse path establishes the restricted context.
                    return httpx.Response(200,json=nav(row('One More Time'),row('Digital Love')))
            return httpx.Response(200,json={})
        output=self.client(handler).spotify_artist_preview('Daft Punk')
        self.assertTrue(output['ready_to_play'])
        self.assertEqual(output['count'],2)
        self.assertEqual(output['source'],'artist_browse')
        self.assertEqual({x['artist'] for x in output['tracks']},{'Daft Punk'})
        self.assertEqual(output['diagnostics']['browse_tracks'],2)

    def test_search_fallback_even_when_browse_has_only_cover(self):
        def handler(req):
            if req.url.path.endswith('/search'):
                return httpx.Response(200,json=nav(
                    row('Daft Punk',uri='spotify:artist:real',kind='folder'),
                    row('One More Time','Daft Punk'), row('Digital Love','Daft Punk')))
            if req.url.path.endswith('/browse'):
                return httpx.Response(200,json=nav(row('Bad Guy',artist='Somebody Else')))
            return httpx.Response(200,json={})
        output=self.client(handler).spotify_artist_preview('Daft Punk')
        self.assertTrue(output['ready_to_play'])
        self.assertTrue(output['partial_results'])
        self.assertEqual(output['source'],'search_fallback')
        self.assertEqual(output['diagnostics']['rejected_other_artist'],1)

    def test_search_items_can_be_navigation_items(self):
        def handler(req):
            if req.url.path.endswith('/search'):
                return httpx.Response(200,json={'navigation':{'items':[
                    row('One More Time','Daft Punk'),row('Digital Love','Daft Punk')]}})
            return httpx.Response(404,json={})
        output=self.client(handler).spotify_artist_preview('Daft Punk')
        self.assertTrue(output['ready_to_play'])
        self.assertEqual(output['count'],2)

    def test_missing_artist_in_global_search_and_playlist_is_rejected(self):
        def handler(req):
            if req.url.path.endswith('/search'):
                return httpx.Response(200,json=nav(
                    row('Daft Punk',uri='spotify:artist:real',kind='folder'),
                    row('Unknown 1'), row('Unknown 2')))
            if req.url.path.endswith('/browse'):
                uri=req.url.params.get('uri')
                if uri=='spotify:artist:real':
                    return httpx.Response(200,json=nav(row('Popular Hits',uri='spotify:playlist:top',kind='folder')))
                return httpx.Response(200,json=nav(row('Somebody',artist='Someone Else'),row('Nameless')))
            return httpx.Response(200,json={})
        output=self.client(handler).spotify_artist_preview('Daft Punk')
        self.assertFalse(output['accepted'])
        self.assertEqual(output['count'],0)
        self.assertEqual(output['diagnostics']['rejected_other_artist'],1)
        self.assertEqual(output['diagnostics']['rejected_missing_artist'],3)

    def test_related_artist_does_not_inherit_name(self):
        def handler(req):
            if req.url.path.endswith('/search'):
                return httpx.Response(200,json=nav(row('Daft Punk',uri='spotify:artist:real',kind='folder')))
            if req.url.path.endswith('/browse'):
                return httpx.Response(200,json=nav(row('Justice',uri='spotify:artist:other',kind='folder')))
            return httpx.Response(200,json={})
        output=self.client(handler).spotify_artist_preview('Daft Punk')
        self.assertFalse(output['accepted'])
        self.assertEqual(output['diagnostics']['browse_requests'],1)

    def test_queue_uses_different_tracks_and_only_one_post(self):
        posts=[]
        def handler(req):
            if req.url.path.endswith('/search'):
                return httpx.Response(200,json=nav(row('Daft Punk',uri='spotify:artist:real',kind='folder')))
            if req.url.path.endswith('/browse'):
                uri=req.url.params.get('uri')
                if uri=='spotify:artist:real':
                    return httpx.Response(200,json=nav(row('Discovery',uri='spotify:album:disc',kind='folder')))
                return httpx.Response(200,json=nav(row('One More Time'),row('One More Time (Radio Edit)'),row('Digital Love')))
            if req.url.path.endswith('/replaceAndPlay'):
                posts.append(json.loads(req.content));return httpx.Response(200,json={'success':True})
            return httpx.Response(404,json={})
        output=self.client(handler).spotify_artist_play('Daft Punk',limit=20)
        self.assertTrue(output['accepted'])
        self.assertEqual(output['count'],2)
        self.assertEqual(len(posts),1)
        self.assertEqual(len(posts[0]['list']),2)

if __name__=='__main__':unittest.main()
