"""Small, strict Volumio REST client for the Waveshare Companion (Volumio 4 / spop).

Only sends traffic to VOLUMIO_URL. HTTP response=success is *acknowledgement*,
not proof that playback actually started; the state must be checked separately.
"""
from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher
import os
import random
import re
import unicodedata
from typing import Any

import httpx

ARTIST_PREVIEW_REV = '0.6.1'
SPOTIFY_SERVICES = frozenset({'spop', 'spotify'})
PLAYABLE_TYPES = frozenset({'song', 'track'})
COMMANDS = frozenset({'play', 'pause', 'stop', 'next', 'prev', 'toggle'})


class VolumioError(Exception):
    pass


class VolumioUnavailable(VolumioError):
    pass


@dataclass(frozen=True)
class Track:
    title: str
    artist: str
    album: str
    uri: str
    service: str
    type: str
    albumart: str = ''

    def as_dict(self) -> dict[str, str]:
        return self.__dict__.copy()


def _normalize(s: str) -> str:
    s = unicodedata.normalize('NFKD', s.casefold())
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return ' '.join(re.findall(r'\w+', s))


def _parse_song_artist(query: str) -> tuple[str, str] | None:
    """Split an explicit voice request 'Titel von Interpret' without guessing."""
    m = re.fullmatch(r'\s*(.+?)\s+von\s+(.+?)\s*', query, re.IGNORECASE)
    if not m:
        return None
    title, artist = m.groups()
    # Preserve parentheses in the title so explicit version requests survive.
    # They are significant for "Radio Edit", "Remix", etc.
    return (title.strip(), _normalize(artist)) if title.strip() and _normalize(artist) else None


# A Spotify song may be listed with "(feat. ...)", on an album, as a radio
# edit or as a remix. The user's query must control which one is meant.
_FEATURE = re.compile(r'\s*[\[(][^]\)]*\b(?:feat\.?|featuring|ft\.?)\b[^]\)]*[\])]', re.I)
_VERSION = re.compile(r'\b(remix|radio edit|radio mix|drumless|acoustic|instrumental|extended(?: mix| version)?|live|remaster(?:ed)?|sped up|slowed)\b', re.I)
_BRACKET = re.compile(r'\s*[\[(][^]\)]*[\])]', re.I)
_DASH_VERSION = re.compile(r'\s+[–—-]\s+[^–—-]*\b(?:remix|radio edit|radio mix|drumless|acoustic|instrumental|extended|live|remaster(?:ed)?)\b.*$', re.I)


def _variant(title: str) -> str:
    """Distinguish actual recordings, never infer a remix from an artist name."""
    cleaned = _FEATURE.sub(' ', title)
    m = _VERSION.search(cleaned)
    if not m:
        return ''
    value = m.group(1).casefold()
    if value in ('radio edit', 'radio mix'):
        return 'radio'
    if value in ('remaster', 'remastered'):
        return 'remaster'
    if value.startswith('extended'):
        return 'extended'
    return value.replace(' ', '_')


def _root_title(title: str) -> str:
    """Strip only documented version/feature labels; keep the actual title."""
    value = _FEATURE.sub(' ', title)
    value = _DASH_VERSION.sub(' ', value)
    value = _BRACKET.sub(lambda m: ' ' if _VERSION.search(m.group(0)) else m.group(0), value)
    return _normalize(value)


def _remix_name(title: str) -> str:
    """Get 'daft punk' from either '(Daft Punk Remix)' or '- Daft Punk Remix'."""
    text = _FEATURE.sub(' ', title)
    m = re.search(r'(?:\(|\[|\s+[–—-]\s+)([^()\]–—-]*?)\s+remix\b', text, flags=re.I)
    if not m:
        return ''
    return _normalize(m.group(1))


def _score(query: str, track: Track) -> float:
    """Rank requested song, artist AND version, not merely overlapping tokens.

    With a named artist, prefer the standard album recording unless the user
    explicitly asks for a remix/edit. Without an artist, do not guess between
    different artists with the same title.
    """
    q = _normalize(query)
    title = _normalize(track.title)
    artist = _normalize(track.artist)
    combined = f'{title} {artist}'.strip()
    reverse = f'{artist} {title}'.strip()
    if not q or not title:
        return 0.0

    explicit = _parse_song_artist(query)
    if explicit:
        wanted_title, wanted_artist = explicit
    else:
        # Also support common typed input "Get Lucky Daft Punk".
        plain_root = _root_title(track.title)
        artist_suffix = ' ' + artist if artist else None
        if artist_suffix and q.endswith(artist_suffix) and q[:-len(artist_suffix)] == plain_root:
            wanted_title, wanted_artist = plain_root, artist
        else:
            wanted_title, wanted_artist = query, None

    root_match = _root_title(wanted_title) == _root_title(track.title)
    if root_match:
        if wanted_artist is not None and artist != _normalize(wanted_artist):
            # 'Daft Punk Tribute' must never be accepted as Daft Punk.
            return 0.64 if artist else 0.45
        requested_variant = _variant(wanted_title)
        candidate_variant = _variant(track.title)
        # Some Volumio listings put "Radio Edit" only in the single album.
        if not candidate_variant and _root_title(track.album) == _root_title(track.title):
            candidate_variant = _variant(track.album)
        if requested_variant:
            if candidate_variant != requested_variant:
                return 0.55
            if requested_variant == 'remix':
                requested_remixer = _remix_name(wanted_title)
                candidate_remixer = _remix_name(track.title) or _remix_name(track.album)
                if requested_remixer and requested_remixer != candidate_remixer:
                    return 0.60
            return 0.99
        if candidate_variant:
            # No variant specified means standard album recording, not a remix.
            return {'radio': 0.84, 'remaster': 0.88, 'extended': 0.77,
                    'drumless': 0.73, 'remix': 0.68, 'live': 0.70,
                    'acoustic': 0.71, 'instrumental': 0.70,
                    'sped_up': 0.67, 'slowed': 0.67}.get(candidate_variant, 0.72)
        # Exact, unmodified title; same artist if specified.
        return 0.99 if wanted_artist is not None else 0.96

    # Fuzzy fallback for non-exact queries, always below a strong explicit match.
    if q == combined or q == reverse:
        return 0.98
    if q == title:
        return 0.96
    if q == artist:
        return 0.45  # Artist alone is not a specific song.
    if q in combined:
        return 0.85
    if explicit:
        wanted, who = explicit
        # Keep an explicit wrong title/artist from being accepted on token overlap.
        title_similarity = SequenceMatcher(None, _normalize(wanted), title).ratio()
        artist_similarity = SequenceMatcher(None, _normalize(who), artist).ratio()
        return round(min(0.78, title_similarity * 0.55 + artist_similarity * 0.22), 4)
    words = set(q.split())
    overlap = len(words & set(combined.split())) / max(1, len(words))
    return min(0.79, 0.5 * overlap + 0.3 * SequenceMatcher(None, q, combined).ratio())


def _recording_key(track: Track) -> tuple[str, str, str]:
    """Collapse duplicate releases, but keep remix/radio/album distinct."""
    root, artist = _root_title(track.title), _normalize(track.artist)
    variant = _variant(track.title)
    if not variant and _root_title(track.album) == root:
        variant = _variant(track.album)
    if variant == 'remix':
        variant += ':' + (_remix_name(track.title) or _remix_name(track.album))
    return (root, artist, variant) if artist else (root, track.uri, variant)


def _release_preference(track: Track) -> tuple[int, int]:
    """Prefer releases with informative album metadata, not empty listings."""
    album = _normalize(track.album)
    if not album:
        return (0, 0)
    compilation = any(x in album for x in ('greatest hits', 'the best', 'compilation',
                                           'karaoke', 'tribute', 'deluxe', 'anniversary'))
    return (0 if compilation else 1, len(album))


class VolumioClient:
    def __init__(self, base_url: str | None = None, *, transport: httpx.BaseTransport | None = None, timeout: float = 5.0):
        base_url = (base_url or os.getenv('VOLUMIO_URL', 'http://192.168.2.241')).rstrip('/')
        url = httpx.URL(base_url)
        if url.scheme != 'http' or not url.host or url.userinfo or url.path not in ('', '/') or url.query or url.fragment:
            raise ValueError('VOLUMIO_URL must be an unadorned http://host[:port] URL')
        self.base_url = base_url
        self._transport = transport
        self.timeout = timeout

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return self._request('GET', path, params=params)

    def _post(self, path: str, data: dict[str, Any]) -> Any:
        return self._request('POST', path, json=data)

    def _request(self, method: str, path: str, **kwargs) -> Any:
        try:
            with httpx.Client(timeout=self.timeout, transport=self._transport, trust_env=False,
                              follow_redirects=False) as client:
                response = client.request(method, self.base_url + path, **kwargs)
                response.raise_for_status()
                try:
                    result = response.json()
                except ValueError as exc:
                    raise VolumioError(f'Volumio lieferte kein JSON für {path}') from exc
                if isinstance(result, dict) and (
                    result.get('response') in ('error', 'failure') or result.get('success') is False
                ):
                    raise VolumioError('Volumio hat den Befehl abgelehnt')
                return result
        except (httpx.TimeoutException, httpx.NetworkError, httpx.ProtocolError, httpx.HTTPStatusError) as exc:
            raise VolumioUnavailable(f'Volumio {self.base_url} nicht erreichbar oder HTTP-Fehler: {type(exc).__name__}') from exc

    def state(self) -> dict[str, Any]:
        state = self._get('/api/v1/getState')
        if not isinstance(state, dict):
            raise VolumioError('Ungültiger Playerstatus')
        keys = ('status', 'title', 'artist', 'album', 'albumart', 'service', 'volume', 'mute', 'uri', 'duration', 'seek')
        return {key: state.get(key) for key in keys}

    def command(self, action: str) -> dict[str, Any]:
        if action not in COMMANDS:
            raise ValueError('Unzulässiger Playerbefehl')
        ack = self._get('/api/v1/commands/', {'cmd': action})
        return {'accepted': True, 'action': action, 'ack': ack}

    def set_volume(self, volume: int) -> dict[str, Any]:
        if isinstance(volume, bool) or not isinstance(volume, int) or not 0 <= volume <= 100:
            raise ValueError('Lautstärke muss zwischen 0 und 100 liegen')
        ack = self._get('/api/v1/commands/', {'cmd': 'volume', 'volume': volume})
        return {'accepted': True, 'volume': volume, 'ack': ack}

    def change_volume(self, delta: int) -> dict[str, Any]:
        state = self.state()
        if state['volume'] is None:
            raise VolumioError('Lautstärke lässt sich nicht abfragen')
        try:
            volume = int(state['volume'])
        except (TypeError, ValueError) as exc:
            raise VolumioError('Ungültiger Lautstärkewert') from exc
        return self.set_volume(max(0, min(100, volume + delta)))

    def mute(self, enabled: bool) -> dict[str, Any]:
        ack = self._get('/api/v1/commands/', {'cmd': 'volume', 'volume': 'mute' if enabled else 'unmute'})
        return {'accepted': True, 'mute': enabled, 'ack': ack}

    def browse_sources(self) -> dict[str, Any]:
        data = self._get('/api/v1/browse')
        nav = data.get('navigation', {}) if isinstance(data, dict) else {}
        sources = [item for item in nav.get('lists', []) if isinstance(item, dict)]
        return {'spotify_visible': any('spotify' in str(item.get('name', '')).casefold() or item.get('uri') == 'spotify' for item in sources),
                'sources': [{'name': x.get('name'), 'uri': x.get('uri')} for x in sources[:50]]}

    def spotify_search(self, query: str, limit: int = 8) -> dict[str, Any]:
        if not isinstance(query, str) or not 3 <= len(query.strip()) <= 120:
            raise ValueError('Suchbegriff muss 3 bis 120 Zeichen enthalten')
        if not 1 <= limit <= 20:
            raise ValueError('limit muss 1 bis 20 sein')
        data = self._get('/api/v1/search', {'query': query.strip()})
        nav = data.get('navigation', {}) if isinstance(data, dict) else {}
        lists = nav.get('lists', []) if isinstance(nav, dict) else []
        if not isinstance(lists, list):
            raise VolumioError('Unerwartetes Suchergebnisformat')
        results: list[Track] = []
        for group in lists:
            items = group.get('items', []) if isinstance(group, dict) else []
            if not isinstance(items, list):
                continue
            for item in items:
                if not isinstance(item, dict):
                    continue
                uri = item.get('uri') or ''
                service = str(item.get('service') or '').casefold()
                # Only returned Spotify items, never local files or other services.
                if service not in SPOTIFY_SERVICES or not isinstance(uri, str) or not uri.startswith('spotify:'):
                    continue
                results.append(Track(
                    title=str(item.get('title') or item.get('name') or ''),
                    artist=str(item.get('artist') or ''), album=str(item.get('album') or ''),
                    uri=uri, service=service, type=str(item.get('type') or '').casefold(),
                    albumart=str(item.get('albumart') or ''),
                ))
        results.sort(key=lambda x: _score(query, x), reverse=True)
        return {'query': query.strip(), 'source': 'volumio_rest_search',
                'supported': bool(results),
                'candidates': [x.as_dict() for x in results[:limit]],
                'message': ('Spotify-Treffer gefunden.' if results else
                            'Volumio lieferte keine Spotify-Treffer. Prüfe Plugin-Anmeldung und die Spotify-Suche in Volumio.')}

    def spotify_play(self, query: str) -> dict[str, Any]:
        result = self.spotify_search(query, limit=20)
        candidates = [Track(**item) for item in result['candidates'] if item['type'] in PLAYABLE_TYPES]
        if not candidates:
            return {'accepted': False, 'reason': 'no_tracks', 'message':
                    'Keine abspielbaren Spotify-Titel gefunden. Prüfe die Spotify-Anmeldung.',
                    'candidates': result['candidates'][:5]}
        ranked = sorted(((t, _score(query, t)) for t in candidates), key=lambda x: x[1], reverse=True)
        # Spotify often returns the same song on several albums / compilations.
        # They must not compete against one another as separate alternatives.
        groups: dict[tuple[str, str], tuple[Track, float, int]] = {}
        for t, score in ranked:
            key = _recording_key(t)
            if key not in groups:
                groups[key] = (t, score, 1)
            else:
                prev, old_score, n = groups[key]
                chosen = t if _release_preference(t) > _release_preference(prev) else prev
                groups[key] = (chosen, max(old_score, score), n + 1)
        distinct = sorted(groups.values(), key=lambda x: x[1], reverse=True)
        best, score, duplicates = distinct[0]
        runner_score = distinct[1][1] if len(distinct) > 1 else 0.0
        if score < 0.80 or (len(distinct) > 1 and score - runner_score < 0.08):
            return {'accepted': False, 'reason': 'ambiguous' if score >= 0.80 else 'low_confidence',
                    'message': ('Kein eindeutiger Treffer. Bitte nenne Titel und Interpret genauer.'
                                if score >= 0.80 else
                                'Titel oder Interpret nicht sicher erkannt. Bitte genauer nennen.'),
                    'query': query, 'candidates': [
                        {**t.as_dict(), 'match_score': round(s, 3), 'releases': n}
                        for t, s, n in distinct[:5]
                    ]}
        item = best.as_dict()
        ack = self._post('/api/v1/replaceAndPlay', item)
        return {'accepted': True, 'action': 'spotify_play', 'track': item, 'ack': ack,
                'duplicate_releases_ignored': duplicates - 1,
                'message': f'Wiedergabe von {best.title} von {best.artist} angefordert.'}

    @staticmethod
    def _navigation_items(data: Any) -> list[dict[str, Any]]:
        """Read typical Volumio REST browse/search response shapes, bounded.

        The Spotify plugin can put items under navigation.lists[*].items,
        navigation.items, or items. Ignore unrelated result metadata.
        """
        if not isinstance(data, dict):
            return []
        navigation = data.get('navigation')
        if not isinstance(navigation, dict):
            navigation = {}
        result: list[dict[str, Any]] = []
        for group in navigation.get('lists', []) if isinstance(navigation.get('lists'), list) else []:
            if isinstance(group, dict) and isinstance(group.get('items'), list):
                result.extend(i for i in group['items'] if isinstance(i, dict))
        for parent in (navigation, data):
            if isinstance(parent.get('items'), list):
                result.extend(i for i in parent['items'] if isinstance(i, dict))
        return result[:500]

    def _spotify_search_items(self, query: str) -> list[dict[str, Any]]:
        """Unabridged Volumio results; Spotify search can contain browse nodes."""
        return self._navigation_items(self._get('/api/v1/search', {'query': query}))

    def spotify_artist_preview(self, artist: str, *, limit: int = 20) -> dict[str, Any]:
        """Read-only, bounded Spotify artist browse plus exact-artist search fallback.

        Never treat arbitrary search results as artist songs: the root must be an
        exact artist match, or a track must have a matching artist field. Only
        missing artist metadata inside the verified artist's own album/browse
        tree may inherit its artist name.
        """
        if not isinstance(artist, str) or not 2 <= len(artist.strip()) <= 100:
            raise ValueError('Interpret muss 2 bis 100 Zeichen enthalten')
        if isinstance(limit, bool) or not 2 <= limit <= 20:
            raise ValueError('limit muss zwischen 2 und 20 liegen')
        wanted = _normalize(artist)
        items = self._spotify_search_items(artist.strip())
        artist_uris: list[str] = []
        for item in items:
            uri = item.get('uri') or ''
            label = str(item.get('title') or item.get('name') or '')
            # Spotify URI and exact name are stronger evidence than an optional
            # service tag on browse folders; some Volumio builds omit it.
            if isinstance(uri, str) and uri.startswith('spotify:artist:') and _normalize(label) == wanted:
                artist_uris.append(uri)

        diagnostics: dict[str, Any] = {
            'artist_nodes': len(set(artist_uris)),
            'search_items': len(items),
            'browse_requests': 0,
            'browse_items': 0,
            'browse_errors': 0,
            'browse_tracks': 0,
            'search_tracks': 0,
            'rejected_other_artist': 0,
            'rejected_missing_artist': 0,
            'distinct_tracks': 0,
        }

        # Track candidate and whether its parent was an artist/album under an
        # EXACTLY matched Spotify artist (not an unrelated playlist).
        found: list[tuple[dict[str, Any], bool, str]] = []
        pending: list[tuple[str, bool]] = [(u, True) for u in dict.fromkeys(artist_uris)][:3]
        visited: set[str] = set()
        while pending and diagnostics['browse_requests'] < 24 and len(found) < max(80, limit * 5):
            uri, trusted_context = pending.pop(0)
            if uri in visited:
                continue
            visited.add(uri)
            diagnostics['browse_requests'] += 1
            try:
                subitems = self._navigation_items(self._get('/api/v1/browse', {'uri': uri, 'limit': 100}))
            except VolumioError:
                diagnostics['browse_errors'] += 1
                continue
            diagnostics['browse_items'] += len(subitems)
            for item in subitems:
                item_uri = item.get('uri')
                if not isinstance(item_uri, str) or not item_uri.startswith('spotify:'):
                    continue
                # Spotify URI proves origin even if the optional service field
                # is missing. An explicitly different service must be rejected.
                service = str(item.get('service') or '').casefold()
                if service and service not in SPOTIFY_SERVICES:
                    continue
                if item_uri.startswith('spotify:track:'):
                    found.append((item, trusted_context, 'browse'))
                    diagnostics['browse_tracks'] += 1
                elif item_uri.startswith(('spotify:album:', 'spotify:artist:', 'spotify:playlist:')):
                    # Related artists are not the requested artist: never
                    # inherit the requested name from a different artist URI.
                    if item_uri.startswith('spotify:artist:') and item_uri not in artist_uris:
                        continue
                    if item_uri not in visited and len(pending) < 80:
                        # Playlist results could contain other artists; never
                        # inherit artist data from a playlist alone.
                        next_trusted = trusted_context and not item_uri.startswith('spotify:playlist:')
                        pending.append((item_uri, next_trusted))

        # Always include search results, even when a browse returned *some*
        # tracks which later fail metadata validation. Previously any browse
        # hit completely disabled the useful search fallback.
        for item in items:
            if str(item.get('uri') or '').startswith('spotify:track:'):
                diagnostics['search_tracks'] += 1
                found.append((item, False, 'search'))

        def primary_artist(value: str) -> str:
            return re.split(r'\s*(?:,|&|;|\bfeat\.?\b|\bfeaturing\b)\s*',
                            value, maxsplit=1, flags=re.I)[0]

        uniques: dict[str, Track] = {}
        browse_accepted = False
        browse_roots: set[str] = set()
        for item, trusted_context, origin in found:
            uri = item.get('uri')
            if not isinstance(uri, str) or not uri.startswith('spotify:track:'):
                continue
            service = str(item.get('service') or '').casefold()
            if service and service not in SPOTIFY_SERVICES:
                continue
            listed_artist = str(item.get('artist') or '')
            if listed_artist:
                if _normalize(primary_artist(listed_artist)) != wanted and _normalize(listed_artist) != wanted:
                    diagnostics['rejected_other_artist'] += 1
                    continue
            elif not trusted_context:
                diagnostics['rejected_missing_artist'] += 1
                continue
            else:
                # Preserve a verified browse context, not a fabricated claim
                # about a track returned by a global Spotify search.
                listed_artist = artist.strip()
            title = str(item.get('title') or item.get('name') or '')
            root = _root_title(title)
            if not root:
                continue
            dtype = str(item.get('type') or 'song').casefold()
            if dtype not in PLAYABLE_TYPES:
                continue
            track = Track(title=title, artist=listed_artist,
                          album=str(item.get('album') or ''), uri=uri,
                          service=service or 'spop', type=dtype,
                          albumart=str(item.get('albumart') or ''))
            previous = uniques.get(root)
            if previous is None or (_variant(previous.title) and not _variant(track.title)) or (
                _variant(previous.title) == _variant(track.title) and
                _release_preference(track) > _release_preference(previous)
            ):
                uniques[root] = track
            if origin == 'browse':
                browse_accepted = True
                browse_roots.add(root)
        diagnostics['distinct_tracks'] = len(uniques)
        selected = list(uniques.values())
        source = 'artist_browse' if browse_accepted else 'search_fallback'
        partial = not browse_accepted or bool(set(uniques) - browse_roots)
        if len(selected) < 2:
            return {'accepted': False, 'reason': 'insufficient_artist_tracks',
                    'artist': artist, 'count': len(selected), 'source': source,
                    'partial_results': partial, 'diagnostics': diagnostics,
                    'message': ('Ich habe nicht genügend verschiedene Titel von '
                                f'{artist} gefunden, um eine Musikauswahl zu starten.')}
        random.SystemRandom().shuffle(selected)
        selected = selected[:limit]
        playlist = [t.as_dict() for t in selected]
        return {'ready_to_play': True, 'artist': artist,
                'count': len(playlist), 'source': source,
                'partial_results': partial, 'tracks': playlist,
                'diagnostics': diagnostics}

    def spotify_artist_play(self, artist: str, *, limit: int = 20) -> dict[str, Any]:
        """Submit a queue only after a successful read-only preview."""
        preview = self.spotify_artist_preview(artist, limit=limit)
        if not preview.get('ready_to_play'):
            return preview
        playlist = preview['tracks']
        # Documented Volumio REST payload: item+list+index. No need to issue
        # separate clear/add calls that can leave a half-written live queue.
        ack = self._post('/api/v1/replaceAndPlay',
                         {'item': playlist[0], 'list': playlist, 'index': 0})
        return {
            'accepted': True, 'action': 'artist_play', 'artist': artist,
            'count': len(playlist), 'source': preview['source'],
            'partial_results': preview['partial_results'],
            'message': f'Ich spiele {len(playlist)} verschiedene Songs von {artist}.',
            'ack': ack,
        }
