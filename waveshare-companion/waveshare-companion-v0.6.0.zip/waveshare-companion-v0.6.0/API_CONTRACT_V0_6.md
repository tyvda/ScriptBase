# Waveshare ↔ Companion ↔ Volumio / Spotify – API-Vertrag v0.6.0

**Stand:** 2026-11-23 · **Server:** Ubuntu LTS `http://192.168.2.207:8000` · **Player:** Volumio `http://192.168.2.241` mit Spotify-Plugin `spop` 4.5.0. Die IP-Adressen sind konfigurierbar.

Dies ist die normative Schnittstelle für die **vorhandene** ESP32-S3-Touch-AMOLED-Firmware (480×480). Der v0.4.1-Audiovertrag bleibt kompatibel; v0.6 ergänzt `ui`, Artist-Play und eine zeitlich begrenzte Titelwahl. **Kein Auth-Token**; Nutzung ausschließlich im vertrauenswürdigen LAN. Firmware spricht **nur den Companion-Server** an, nicht Volumio oder Spotify direkt (Albumcover ausgenommen).

## 1. Transport und Audio

- HTTP/1.1, unverschlüsselt im lokalen Netz; JSON UTF-8, sofern nicht anders angegeben. Kein WebSocket-Push notwendig.
- `GET /health` → `200 {"ok":true}` prüft nur den Prozess, **nicht** die Modelle oder Volumio.
- `GET /ready` → `200` oder `503` für Whisper, Piper, FFmpeg, Ollama; Volumio wird dabei **nicht** geprüft.
- `POST /api/turns` mit Header `Content-Type: audio/wav` und rohem WAV-Body: **16.000 Hz, PCM s16le, mono, max. 10 Sekunden / 160.000 Samples**. Kein Multipart, kein Base64, **max. 320.044 Byte** bei kanonischem Header.
- Upload → `202 application/json {"id":"<UUID>","state":"queued"}`; alternativ `?plain=1` → `202 text/plain` mit UUID.
- `GET /api/turns/{turn_id}` → `200` mit dem vollständigen Turn-Objekt (unten). `GET /api/turns/{turn_id}/state` → Klartext. `GET /api/turns/{turn_id}/events` → SSE mit vollständigem Turn-Objekt bei Statusänderung (optional). `DELETE /api/turns/{turn_id}` → Best-Effort-Abbruch.
- `GET /api/turns/{turn_id}/audio.wav` → `200 audio/wav` **erst** bei `ready`, sonst `409`. Antwort **16 kHz / s16le / mono**. ESP32 darf die Datei blockweise abspielen.
- Statusfolge: `queued` → `transcribing` → `thinking` → `speaking` → `ready`; terminal alternativ `failed` / `cancelled`. `speaking` bedeutet TTS-Erzeugung am Server, nicht Lautsprecherwiedergabe.

## 2. Turn-Objekt (WAV → Backend → Touchscreen)

**Unveränderte Felder:** `id`, `session_id` (`null` oder UUID), `state`, `transcript`, `answer`, `error`, `created_at` (ISO 8601). **Neu (optional):** `ui`, entweder `null` oder Objekt `track_selection`.

Normaler Status:

```json
{
  "id":"71c1d302-b05d-4be1-983b-4283849e4254",
  "session_id":null,"state":"ready",
  "transcript":"Was läuft gerade?",
  "answer":"Gerade läuft Get Lucky von Daft Punk.",
  "error":"","created_at":"2026-11-23T12:00:00+00:00",
  "ui":null
}
```

Mehrdeutige Spotify-Suche (der Server hat **noch nichts gestartet**):

```json
{
  "id":"71c1d302-b05d-4be1-983b-4283849e4254",
  "session_id":null,"state":"ready",
  "transcript":"Spiele Get Lucky",
  "answer":"Ich habe mehrere passende Songs gefunden. Wähle einen auf dem Display aus.",
  "error":"","created_at":"2026-11-23T12:00:00+00:00",
  "ui":{
    "type":"track_selection",
    "selection_id":"Tq4ndm4pOlR9HrruGFqKsTxG",
    "query":"get lucky",
    "expires_at":"2026-11-23T12:02:00+00:00",
    "items":[
      {"candidate_id":"a719cc52e9fc","title":"Get Lucky","artist":"Daft Punk","album":"Random Access Memories","version":"Standard","albumart":"https://i.scdn.co/image/..."},
      {"candidate_id":"e3fe66f909d2","title":"Get Lucky","artist":"Loi","album":"","version":"Standard","albumart":"https://i.scdn.co/image/..."}
    ]
  }
}
```

Die Werte sind **Beispiele**, keine realen Sitzungs-IDs. Die **Auswahl-IDs sind opaque**: weder Indizes noch Spotify-URIs ableiten, serialisieren oder selbst erzeugen. `items` enthält **1–8** Datensätze, in der vom Server vorgegebenen Reihenfolge. `albumart` kann leer oder relativ sein; bei fehlendem Bild Platzhalter zeigen. `ui` kann bereits bei `speaking` vorhanden sein; spätestens ab `ready` auswerten.

### Frontend-Zustandsablauf

1. Gerät nimmt WAV (max. 10 s) auf und startet `POST /api/turns`. `202`: UUID speichern; **POST nicht blind wiederholen** (kein Idempotency-Key).
2. Bis `ready|failed|cancelled` alle ca. **1–2 s** Status abfragen. HTTP `404` nach Backend-Neustart: alten Turn verwerfen. UI-JSON defensiv parsen; unbekannte `ui.type` ignorieren.
3. `ready`: WAV-Antwort wie bisher laden und abspielen. Bei `ui.type=track_selection` zusätzlich den Titelauswahldialog öffnen. Die TTS-Antwort ist eine Rückfrage, **keine automatische Auswahl**.
4. Beim Wischen nur lokalen Kartenindex verändern. **Erst bei Tippen auf „Abspielen“** die Auswahlbestätigung auslösen; Netzwerkaufruf asynchron / nicht im LVGL-Event-Callback blockierend.
5. Auf `accepted:true` Auswahl schließen, dann optional `GET /api/volumio/status` zum Prüfen, ob der Player tatsächlich spielt. HTTP-Ack ist keine Wiedergabegarantie.
6. Der Server verwirft Auswahlen nach **120 Sekunden**, unabhängig von der Gerätezeit. Bei `410` Dialog schließen und neue Suche anbieten. Während Wiedergabe `ui` lokal auf `null` setzen.

## 3. Volumio-Erweiterungen (neue Endpunkte)

### 3.1 Capabilities

`GET /api/volumio/v06/capabilities` → `200`:

```json
{"version":"0.6.0","artist_play":true,"track_selection":true,"selection_ttl_seconds":120,"max_selection_items":8,"volumio_enabled":true}
```

Erfolgreicher Capability-Check bedeutet **nicht**, dass Spotify angemeldet oder erreichbar ist. Bei `volumio_enabled:false` Volumio-UI deaktivieren.

### 3.2 Künstler – Vorschau (read-only)

`GET /api/volumio/spotify/artist/preview?artist=Daft%20Punk&limit=20`

Bei mindestens zwei verschiedenen Titeln: `200`:

```json
{
  "ready_to_play":true,"artist":"Daft Punk","count":3,
  "source":"artist_browse","partial_results":false,
  "tracks":[
    {"title":"One More Time","artist":"Daft Punk","album":"Discovery","uri":"spotify:track:...","service":"spop","type":"song","albumart":"..."}
  ]
}
```

`source` ist `artist_browse` (verfügbare Spotify-Künstler-/Album-Navigation) oder `search_fallback` (nur passende Suchresultate). Bei `search_fallback` **`partial_results:true`**, weil die Spotify-Suche keine vollständige Diskografie garantiert. `tracks` ist schon gemischt, bis zu `limit` verschiedene Titel. Die Vorschau verändert Volumio **nicht**. Falls zu wenig Titel gefunden: `ready_to_play` fehlt / `accepted:false`, `reason:"insufficient_artist_tracks"`, `count` und `message`; **kein** Queue-POST.

### 3.3 Künstler – abspielen (verändert Playlist)

`POST /api/volumio/spotify/artist/play`, `Content-Type: application/json`:

```json
{"artist":"Daft Punk","limit":20}
```

Erfolg `200`:

```json
{
  "accepted":true,"action":"artist_play","artist":"Daft Punk",
  "count":20,"source":"artist_browse","partial_results":false,
  "message":"Ich spiele 20 verschiedene Songs von Daft Punk.","ack":{"success":true}
}
```

Der Server wählt **ausschließlich exakte Hauptinterpreten**; unterschiedliche Songs nach Grundtitel, möglichst Originalversion; keine Cover fremder Interpreten und keine Duplikate. Aus der Spotify-Suche werden höchstens die dort verfügbaren Treffer verwendet; der Client darf die Anzahl **nicht als vollständige Diskografie interpretieren**. Der Controller sendet ein einzelnes `replaceAndPlay` mit `{item, list, index:0}` an Volumio; bereits vorhandene Queue kann ersetzt werden. `accepted:true` bedeutet API-ACK, nicht garantiert hörbaren Ton.

Sprachrouting ohne neue Audioendpunkte:

- „Spiele Musik von Daft Punk“, „Spiel etwas von Daft Punk“, „Spiele Songs von Daft Punk“ → `artist_play`.
- „Spiele Daft Punk“ → prüft erst einen exakt passenden Künstler, ansonsten normale Songsuche.
- „Spiele Get Lucky von Daft Punk“ → bestehende Titelsuche.
- Allgemeine Fragen gehen weiterhin an Ollama.

### 3.4 Titelauswahl vorbereiten

`POST /api/volumio/selections`, Body:

```json
{"query":"Get Lucky"}
```

→ `201 application/json` mit dem **`ui`-Objekt aus §2**, ohne vorherige Wiedergabe. Diese Route ermöglicht eine Touch-initiierte Suche (optional). Der Spracheingabe-Pfad legt die Auswahl automatisch an, wenn die bisherige Spotify-Titelsuche `ambiguous` oder `low_confidence` mit abspielbaren Kandidaten liefert.

### 3.5 Titelauswahl abrufen

`GET /api/volumio/selections/{selection_id}` → `200` mit `ui`-Objekt aus §2. Nur gültige, noch nicht bestätigte Auswahlen sind abrufbar.

### 3.6 Auswahl bestätigen – **einzige Aktion des Swipe-Dialogs**

`POST /api/volumio/selections/{selection_id}/play`, Body:

```json
{"candidate_id":"a719cc52e9fc"}
```

Erfolg `200`:

```json
{
  "accepted":true,
  "selection_id":"Tq4ndm4pOlR9HrruGFqKsTxG",
  "candidate_id":"a719cc52e9fc",
  "track":{"title":"Get Lucky","artist":"Daft Punk","album":"Random Access Memories"},
  "message":"Wiedergabe von Get Lucky von Daft Punk angefordert.",
  "ack":{"success":true}
}
```

Der Server verwendet seine gespeicherte Spotify-URI; die Firmware darf **keine URI einsenden**. Die Auswahl wird **vor** dem Volumio-POST verbraucht, damit auch bei Netzwerk-Timeouts derselbe Klick nicht zwei Songs startet. Ein verlorenes HTTP-ACK darf **nicht** automatisch durch ein erneutes POST kompensiert werden; bei Unsicherheit zuerst `/api/volumio/status` abfragen.

### 3.7 Auswahl verwerfen

`DELETE /api/volumio/selections/{selection_id}` → `200 {"cancelled":true,"selection_id":"..."}`. Kein Playback. Ein bereits bestätigter Dialog lässt sich nicht mehr abbrechen (409).

## 4. Bestehende Volumio-Routen (kompatibel)

- `GET /api/volumio/status` → aktueller Volumio-Playerstatus (inkl. `status`, `title`, `artist`, `album`, `volume`, `albumart`).
- `GET /api/volumio/sources` → sichtbare Quellen.
- `GET /api/volumio/spotify/search?query=...&limit=8` → Treffer inklusive URI (für Debug; normale Firmware nutzt Selection-IDs).
- `POST /api/volumio/spotify/play {"query":"Get Lucky von Daft Punk"}` → weiterhin eindeutige Titelauswahl; bei Mehrdeutigkeit weiterhin `accepted:false` und Kandidaten (verwende im UI **`POST /selections`**).
- `POST /api/volumio/control {"action":"pause"}` usw. → Playerkommando.
- `POST /api/volumio/voice {"text":"..."}` → `handled`, `answer`, **neu zusätzlich** `action`, `ui`.

## 5. Fehler und Lebensdauer

| HTTP | Bedeutung | Verhalten am ESP32 |
|---|---|---|
| `200/201/202` | Erfolg, siehe Route | JSON parsen, UI aktualisieren |
| `400/422` | Falscher Body/Parameter | Bedienungsfehler anzeigen, kein Retry |
| `404` | unbekannte Turn-/Selection-/Candidate-ID | Auswahl verwerfen |
| `409` | Auswahl bereits bestätigt / laufend; oder WAV nicht bereit | keinen doppelten POST; WAV bei `ready` erneut holen |
| `410` | Auswahl älter als 120 s | UI schließen, neue Suche starten |
| `413` | WAV zu groß | Aufnahme kürzen |
| `415` | WAV-Content-Type falsch | Header korrigieren |
| `429` | Backend-Warteschlange voll (max. 8 offene Turns) | begrenztes Backoff |
| `502` | Volumio/Spotify HTTP- oder Netzwerkfehler | nicht blind bestätigen; Playerstatus prüfen |
| `503` | Volumio deaktiviert oder KI nicht bereit | Offlinehinweis |

- Maximal **8 Auswahlkandidaten**, maximal **32 aktive/kurzlebige Auswahleinträge** im Serverprozess; Auswahl läuft nach **120 s** ab. Nach Serverneustart sind Auswahlen und Audio-Jobs weg.
- `selection_id` zufällig und nicht erratbar, `candidate_id` serverseitig erzeugt; kein Benutzer-Account und **keine Authentifizierung**. Firewall: Port 8000 nur für vertrauenswürdige LAN-Clients, nie an das Internet weiterleiten.
- Ein neues Audioturn erzeugt eine neue ID; parallele Turns nicht anhand der Anzeige mischen. Bei `ui` gehört der Dialog genau zu dessen `selection_id`.
- Der ESP32 muss Stringlängen, Anzahl Kandidaten und Dateigröße im Parser selbst begrenzen, externe Cover nur optional laden. Netzwerkkommunikation nicht im LVGL-Event-Thread blockieren.

## 6. Abnahmetests

| ID | Test | Erwartung |
|---|---|---|
| A01 | WAV „Spiele Musik von Daft Punk“ | `artist_play`, 2–20 unterschiedliche Titel, Volumio-ACK; kein ollama-Spielbefehl |
| A02 | WAV „Spiele Get Lucky“ mit mehreren Treffern | `ready` mit `ui.type=track_selection`; Volumio bleibt zunächst unverändert |
| A03 | Auswahl durch Swipe | keine Netzwerkaktion bis zur Bestätigung |
| A04 | POST `selection_id` + `candidate_id` | genau 1 `replaceAndPlay`; HTTP 200 `accepted:true` |
| A05 | derselbe POST erneut | HTTP 409, kein zweiter Volumio-POST |
| A06 | Auswahl nach 120 s | HTTP 410, UI erneuern |
| A07 | DELETE unbestätigte Auswahl | HTTP 200, kein Playback |
| A08 | Artist-Suche ohne Browse | `search_fallback`, `partial_results:true` oder sauberer `insufficient_artist_tracks` |
| A09 | Künstler mit Cover-Songs | nur exakter Künstler in Queue |
| A10 | Standardfrage „Wie spät ist es?“ | unveränderte Ollama-/Piper-Pipeline |
| A11 | Firmware mit v0.5 Server | `ui` fehlt → alte Funktion läuft weiter, kein Crash |
| A12 | Status `failed` / Timeout / WLAN unterbrochen | verständlicher Offlinezustand, kein doppelter POST |

**Live-Hardware-Hinweis:** Spotify-Plugin 4.5.0 kann im Browse andere Knoten und Resultatgrenzen als die dokumentierten Volumio-Beispiele ausgeben. Das Backend berücksichtigt mehrere Formen, aber die tatsächliche Künstler-Warteschlange ist erst nach dem Live-Test auf `192.168.2.241` bestätigt. 
