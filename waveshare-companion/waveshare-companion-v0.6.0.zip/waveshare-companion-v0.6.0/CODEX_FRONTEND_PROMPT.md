# Codex-Arbeitsauftrag: Waveshare ESP32-S3 Companion – Spotify-Karten & Artist-Play v0.6

Du arbeitest **im bereits vorhandenen Firmware-Repository** für das **Waveshare ESP32-S3 Touch AMOLED 2.16**. Der aktuelle Firmware-Stand befindet sich in diesem Codex-Projekt. **Nicht neu anfangen, keine Frameworks auswechseln und keine neuen Pinbelegungen erfinden.** Zuerst Quellbaum, vorhandene LVGL-Version, Touch-Callbacks, Wi-Fi-/HTTP-Code, Recording/I2S, bestehenden WAV-Player und Bildschirm-Staten dokumentieren. Kompilieren und die vorhandenen Tests ausführen. Implementiere darauf aufbauend die folgenden Erweiterungen.

## Backend und Referenz

- Companion-Server: `http://192.168.2.207:8000` (Konfiguration verwenden, nicht hart in vielen Dateien verteilen).
- Volumio: `192.168.2.241`, ausschließlich **vom Backend** angesteuert; ESP32 sendet keine Spotify-URIs direkt an Volumio.
- Normative Schnittstelle: `API_CONTRACT_V0_6.md` aus dem Release `waveshare-companion-volumio-v0.6`. Vor dem Coden lesen.
- `GET /api/volumio/v06/capabilities` prüft `version=0.6.0`, `track_selection=true`, `artist_play=true` und `volumio_enabled=true`. Fallback: ohne neuen Endpunkt kann die alte Sprach-/WAV-Funktion weiterlaufen.
- Kein Auth-Token, kein TLS im bestehenden vertrauenswürdigen LAN; **keine** Passwörter/Netzwerkgeheimnisse in Git.

## Aufgabe A: HTTP/JSON-Integration

- **Nicht** die Audioübertragung verändern: WAV 16 kHz, 16 Bit, mono, höchstens 10 s; `POST /api/turns` → `202`, `GET /api/turns/{id}` bis `ready`, anschließend `GET /api/turns/{id}/audio.wav`.
- Turn-JSON um das **optionale** Feld `ui` ergänzen: `null`, fehlend oder unbekannter Typ müssen ohne Crash wie bisher verarbeitet werden.
- Bei `ui.type == "track_selection"` die Felder `selection_id`, `expires_at` und max. 8 `items` mit `candidate_id`, `title`, `artist`, `album`, `version`, `albumart` lesen. `candidate_id` und `selection_id` exakt als empfangene opake Strings behandeln; nicht Index/URI zur Wahl verwenden.
- Bounds: `items.length <= 8`; Strings vor Kopieren in feste Puffer auf passende Länge begrenzen; nicht blind große JSON-Dokumente in DRAM halten; vorhandene PSRAM-Verwendung nutzen.
- Auswahldaten gehören zur **jeweiligen** `turn_id`, dürfen bei einem zweiten Turn nicht mit dem vorherigen Dialog vermischt werden.

## Aufgabe B: AMOLED-LVGL-UI und Wischgesten

- Erstelle eine **nicht blockierende** Auswahlansicht passend zur **480×480 AMOLED**-UI und deren vorhandener Navigation. Erhalte vorhandene Aufnahme- und Wiedergabestates.
- Visualisierung: eine Karte im Fokus, Titel (mehrzeilig / Ellipsis), Interpret, Album/Version, Albumbild (optional; Platzhalter falls Bild ungültig/leer/nicht geladen), Indikator „1/N“, links/rechts-Wischrichtung, Aktionen „Abspielen“ und „Zurück“.
- LVGL-Wischgeste horizontal (`LV_EVENT_GESTURE` oder die zum Projekt passende Touch-Event-Lösung). Nur Kartenindex ändern, **kein POST auf Swipe**. Alternativ nutzbare Vor/Zurück-Touchflächen für zuverlässige Bedienung.
- Bei „Abspielen“ genau einmal einen Hintergrund-HTTP-Request auslösen: `POST /api/volumio/selections/{selection_id}/play`, JSON `{"candidate_id":"<gewählte ID>"}`. Weitere Klicks während `confirming` sperren. Kein Netzwerkzugriff in LVGL-Ereigniscallbacks.
- `200 accepted:true`: Dialog schließen, Erfolg anzeigen, optional `GET /api/volumio/status` lesen. `409`: bereits bestätigt, Status abfragen, kein Retry-POST. `410`: abgelaufen, Dialog schließen und erneute Suche anbieten. `404`: ungültige ID, Auswahl löschen. `502`/Timeout: unklar, ob Volumio den Titel annahm; **nicht automatisch POST wiederholen**, erst Status lesen. „Zurück“ sendet (optional asynchron) `DELETE /api/volumio/selections/{selection_id}`.
- Auswahl-TTL: **120 s serverseitig**, darf nicht von korrekter ESP32-Wallclock abhängen. Lokale Monotonic-Uhr kann für Countdown genutzt werden; Server-410 bleibt maßgeblich.
- Piper sagt zuvor „Wähle einen Song auf dem Display aus“. Bereits laufendes Audio sauber zu Ende spielen oder geordnet stoppen; keine doppelte I²S-Initialisierung.
- Albumcover: niemals unlimitiert in den RAM laden; Größe und Format prüfen, asynchron laden; vorerst Platzhalter akzeptabel. Für URLs nur sichere bekannte HTTPS-CDNs bzw. das konfigurierte Volumio-Gerät zulassen, bei Fehler kein UI-Blocker.

## Aufgabe C: Künstlerwiedergabe

- Die Sprachformulierung „Spiele Musik von Daft Punk“ wird **backendseitig** zu `artist_play`. Für das ESP32 ist weiterhin das WAV-Protokoll ausreichend. Optional die gesprochene Antwort („Ich spiele 20 verschiedene Songs ...“) und aktuellen Titel auf dem Display zeigen.
- Optional für Touch-UI: `GET /api/volumio/spotify/artist/preview?artist=<urlencoded>&limit=20`, um ohne Wiedergabe eine Künstlerliste anzuzeigen; `POST /api/volumio/spotify/artist/play` mit `{"artist":"Daft Punk","limit":20}` startet die Warteschlange. **Nicht ungefragt starten, solange der Benutzer nur sucht.**
- Das Backend gibt `partial_results:true` zurück, falls nur die eingeschränkte Spotify-Suche statt Künstler-Browse verfügbar ist. Zeige die reale Anzahl statt eine vollständige Diskografie zu behaupten.

## Zustandsmaschine

Erweitere bestehende States minimal um `selection_pending`, `selection_browsing`, `selection_confirming`, `selection_expired`, `selection_error`. Ablauf: `recording → uploading → awaiting_job → ready → [play_tts] → selection_browsing → selection_confirming → idle`. Fehler und Cancel dürfen nicht in Endlosschleifen landen. Keep-alive / SSE ist **nicht** erforderlich; Polling 1–2 s genügt.

## Tests und Lieferumfang

- Build mit **der bereits eingerichteten Toolchain** (kein Frameworkwechsel); bei fehlender Hardware keine Flash-Erfolgsmeldung erfinden.
- Tests/Mocks für `ui` fehlend/null/leer/mehr als 8, überlange Strings, 2–8 Karten, horizontaler Swipe, Einzel-POST auf Bestätigung, 404/409/410/502/Timeout, Job-Kontextwechsel, UI während TTS, fehlende Cover, alter Server ohne v0.6.
- Ein kurzer Demo-Modus mit statischen Kandidaten ist als **Mock** zulässig, darf aber nicht automatisch aktiv sein und keine echte Musik starten.
- Committe nur die erforderlichen Firmware-Änderungen in diesem Codex-Repository, inklusive einer README mit Build- und manuellen ESP32-Testschritten. Zeige die modifizierten Dateien und die tatsächlichen Build-/Testergebnisse. Keine ungeprüften Behauptungen zur Touch- oder Audio-Hardware.

## Beispiel: Auswahl aus dem Audio-Turn

```json
{
  "state": "ready",
  "transcript": "Spiele Get Lucky",
  "answer": "Ich habe mehrere passende Songs gefunden. Wähle einen auf dem Display aus.",
  "ui": {
    "type": "track_selection",
    "selection_id": "OPAQUE_SELECTION_ID",
    "expires_at": "2026-11-23T16:30:00+00:00",
    "items": [
      {"candidate_id":"OPAQUE_ID_A","title":"Get Lucky","artist":"Daft Punk","album":"Random Access Memories","version":"Standard","albumart":""},
      {"candidate_id":"OPAQUE_ID_B","title":"Get Lucky","artist":"Loi","album":"","version":"Standard","albumart":""}
    ]
  }
}
```

Vorgehen: **zuerst bestehenden Firmware-Code untersuchen und Plan mit konkreten Dateipfaden machen; danach implementieren und mit realem Build/Test abschließen**. Rückfragen nur stellen, wenn eine wirklich unauflösbare Hardware-/Toolchain-Anforderung fehlt.
