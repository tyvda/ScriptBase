# Waveshare Companion + Volumio v0.6.0

Ein **inkrementelles, rücksetzbares** Backend-Add-on für deine bestehende Installation auf Ubuntu LTS (`/srv/ai/projects/companion-mvp/server`). Firmware bleibt im separaten Codex-Projekt und wird durch dieses Paket **nicht** verändert.

**Neuer Funktionsumfang**

- Voice: „Spiele Musik von Daft Punk“ → exakter Interpret, unterschiedliche Titel, gemischte Liste (2–20 Titel), Volumio `replaceAndPlay`.
- Voice: „Spiele Daft Punk“ → zuerst exakter Künstler; ansonsten normale Titelsuche.
- Voice: Mehrdeutiger Song → `ui.type=track_selection` im bestehenden `/api/turns/{id}`-Status, noch **keine** Wiedergabe.
- Touch-API: bis zu acht Kandidaten mit opaque `selection_id` und `candidate_id`; Swipe ist nur Frontend; `POST /api/volumio/selections/{id}/play` startet den ausdrücklich ausgewählten Song.
- Auswahlen gelten 120 s, einmalige Bestätigung, kein Wiederholungs-POST nach Timeouts. Normale WAV-, Whisper-, Ollama- und Piper-Pfade bleiben kompatibel.

## Installieren

**Voraussetzungen:** Bereits funktionierender systemd-User-Service `waveshare-companion`, installierte Volumio-Erweiterung v0.5.3+ (typisch v0.5.5), bestehendes Python-venv und `VOLUMIO_URL` auf deinen Server konfiguriert. Dieses Paket führt keinen apt/pip-Upgrade aus.

```bash
cd /srv/ai/projects
unzip -q waveshare-companion-v0.6.0.zip
bash waveshare-companion-v0.6.0/install.sh /srv/ai/projects/companion-mvp/server
```

Installer: Vorabprüfung/AST-Patch in temporärem Verzeichnis; Backup im Serverordner; Installation der 4 Python-Module, optionale Erweiterung von `Turn.ui` und des Music-Worker-Hooks, systemd-Restart, HTTP-Check `/api/volumio/v06/capabilities`. Bei Fehlern stellt er gesicherte Dateien wieder her. `pipeline.py` bleibt unverändert. Der Installer aktiviert `VOLUMIO_ENABLED=1`; `VOLUMIO_URL` wird nur gesetzt, wenn noch kein Wert existiert.

### API-Live-Test ohne Wiedergabe

```bash
/srv/ai/projects/companion-mvp/server/.venv/bin/python \
  /srv/ai/projects/waveshare-companion-v0.6.0/live_probe.py \
  --artist 'Daft Punk' --search 'Get Lucky'
```

Es werden Künstler-Titel und Touch-Kandidaten angezeigt. **Der Test startet keinen Song.** Artist-Browse kann sich zwischen Spotify-Plugin-Versionen unterscheiden: der Rückgabewert `source=search_fallback` und `partial_results=true` meldet eine begrenzte Trefferliste; es wird keine vollständige Diskografie vorgetäuscht.

### Optional: bewusst eine Künstler-Warteschlange starten

```bash
curl -sS -X POST http://127.0.0.1:8000/api/volumio/spotify/artist/play \
  -H 'Content-Type: application/json' \
  -d '{"artist":"Daft Punk","limit":20}'
```

**Achtung:** Dieser Aufruf kann die Volumio-Warteschlange ersetzen. `accepted:true` ist nur die REST-Bestätigung; danach `/api/volumio/status` prüfen.

## Firmware-Integration

`API_CONTRACT_V0_6.md` definiert alle Requests/Responses und Fehlerfälle. `CODEX_FRONTEND_PROMPT.md` ist der Arbeitsauftrag für den **bestehenden Firmware-Stand im Codex-Repository**. Keine neuen Hardware-Treiber oder Audio-Codecs in diesem Backend-Release.

## Tests

```bash
cd /srv/ai/projects/waveshare-companion-v0.6.0
PYTHONPATH=server:tests:. /srv/ai/projects/companion-mvp/server/.venv/bin/python \
  -m unittest discover -s tests -v
```

Lokale Tests simulieren Volumio mit `httpx.MockTransport` und prüfen Artist-Play, Cover-Filter, Auswahlablauf, single-use und bestehende Playerkommandos. Sie ersetzen **nicht** den realen Volumio-/Spotify- und ESP32-Test.

## Architektur- und Sicherheitsgrenzen

- Keine Spotify-API-Schlüssel notwendig: ausschließlich bereits angemeldetes Volumio-Plugin.
- Keine Authentifizierung auf Port 8000: über Firewall auf vertrauenswürdiges LAN begrenzen; niemals Internet-Portfreigabe.
- Bis zu 32 in-memory-Auswahlen, automatisch nach 120 s abgelaufen; nach Backend-Neustart verloren.
- Künstler-Browse: maximal 15 REST-Abfragen über Spotify-URIs, höchstens 20 Titel in der Queue. Bei fehlender Album-Navigation nur exakt zum Künstler passende Spotify-Suchtreffer.
- Abgelaufene IDs 410, unbekannte 404, doppelte Auswahl 409; unklarer Netzwerkfehler **kein** automatischer Retry des Playback-POSTs.

Basis: [Volumio REST API](https://github.com/volumio/docs/blob/master/docs/02_API/04_REST_API.md) · Spotify `spop` 4.5.0. Direkte Live-LAN-Tests auf `192.168.2.241` sind aus dieser Entwicklungsumgebung nicht möglich.
