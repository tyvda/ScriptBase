"""Generate combined OpenAPI schema for the v0.6 add-on and stable WAV routes."""
from __future__ import annotations

from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'server'))

from fastapi import FastAPI, Path as PathParam, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import yaml
import volumio_api

app=FastAPI(title='Waveshare Companion + Volumio',version='0.6.0',
            description='Combined v0.6 contract. Existing WAV routes unchanged, Spotify choice and artist features added.')
app.include_router(volumio_api.router)

class UiTrack(BaseModel):
    candidate_id:str
    title:str
    artist:str
    album:str
    version:str
    albumart:str
class UiSelection(BaseModel):
    type:str='track_selection'
    selection_id:str
    query:str
    expires_at:str
    items:list[UiTrack]
class Turn(BaseModel):
    id:str
    session_id:str|None=None
    state:str
    transcript:str
    answer:str
    error:str
    created_at:str
    ui:UiSelection|None=None
class NewTurn(BaseModel):
    id:str
    state:str='queued'

@app.get('/health',tags=['Audio'])
def health_contract():return {'ok':True}

@app.get('/ready',tags=['Audio'],description='200 when models are configured; else 503')
def ready_contract():return {}

@app.post('/api/turns',tags=['Audio'],response_model=NewTurn,status_code=202,
          description='Raw body, NOT multipart; Content-Type audio/wav; PCM s16le 16k mono <= 10s; 320044 B max.')
def create_turn_contract():return {'id':'uuid','state':'queued'}

@app.get('/api/turns/{turn_id}',tags=['Audio'],response_model=Turn)
def get_turn_contract(turn_id:str=PathParam()):return {}

@app.get('/api/turns/{turn_id}/state',tags=['Audio'],response_class=Response,
         description='UTF-8 text/plain: queued|transcribing|thinking|speaking|ready|failed|cancelled')
def get_turn_state_contract(turn_id:str=PathParam()):return Response(content='ready',media_type='text/plain')

@app.get('/api/turns/{turn_id}/audio.wav',tags=['Audio'],response_class=Response,
         description='16kHz mono PCM WAV; 409 if turn is not ready.')
def get_turn_wav_contract(turn_id:str=PathParam()):return Response(content=b'',media_type='audio/wav')

@app.delete('/api/turns/{turn_id}',tags=['Audio'],response_model=Turn)
def cancel_turn_contract(turn_id:str=PathParam()):return {}

spec=app.openapi()
spec['paths']['/api/turns']['post']['requestBody']={
 'required':True,
 'content':{'audio/wav':{'schema':{'type':'string','format':'binary',
  'description':'PCM signed 16-bit little-endian, 16000Hz, mono, <= 10 s'}}}}
spec['paths']['/api/turns/{turn_id}/audio.wav']['get']['responses']['200']={
 'description':'Answer ready','content':{'audio/wav':{'schema':{'type':'string','format':'binary'}}}}
spec['paths']['/api/turns/{turn_id}/state']['get']['responses']['200']={
 'description':'Plain text state','content':{'text/plain':{'schema':{'type':'string'}}}}
spec['servers']=[{'url':'http://192.168.2.207:8000','description':'Example Ubuntu LAN endpoint; configurable'}]
spec['info']['description'] += ('\n\nNo bearer token; restrict access to trusted LAN. The '
 'authoritative behavior including status codes, expirations, and the UI flow is '
 'documented in API_CONTRACT_V0_6.md. This file is a client-schema supplement.')
Path(__file__).resolve().parent.joinpath('openapi_v0_6.yaml').write_text(
 yaml.safe_dump(spec,allow_unicode=True,sort_keys=False,width=115),encoding='utf-8')
