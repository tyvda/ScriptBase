#!/usr/bin/env bash
# Upgrade v0.5.3/0.5.4/0.5.5 Volumio integration to v0.6.
# Backs up files, verifies target patch in a staging area, and rolls back on errors.
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
TARGET="${1:-/srv/ai/projects/companion-mvp/server}"
SERVICE="waveshare-companion.service"
if [[ ! -f "$TARGET/app.py" || ! -f "$TARGET/pipeline.py" || ! -x "$TARGET/.venv/bin/python" ]]; then
  echo "Backend oder .venv fehlen: $TARGET" >&2; exit 2
fi
if ! command -v systemctl >/dev/null || ! command -v curl >/dev/null; then
  echo 'Fehlt: systemctl oder curl' >&2; exit 2
fi
if ! systemctl --user cat "$SERVICE" >/dev/null 2>&1; then
  echo "systemd-User-Service nicht gefunden: $SERVICE" >&2; exit 2
fi
STAGE="$(mktemp -d)"
trap 'rm -rf -- "$STAGE"' EXIT
cp -p -- "$TARGET/app.py" "$STAGE/app.py"
# Fail before changing the live backend if the installed worker differs.
python3 "$HERE/patch_backend.py" "$STAGE/app.py"
for f in music_agent.py volumio_api.py volumio_controller.py selections.py; do
  cp -- "$HERE/server/$f" "$STAGE/$f"
done
"$TARGET/.venv/bin/python" -m py_compile "$STAGE"/{app,music_agent,volumio_api,volumio_controller,selections}.py
# Validate the new module imports with the same venv used by systemd.
PYTHONPATH="$STAGE:$TARGET" "$TARGET/.venv/bin/python" - <<'PY'
import music_agent, volumio_api, selections
assert music_agent.parse_voice('Spiele Musik von Daft Punk').action == 'artist_play'
assert selections.TTL_SECONDS == 120
PY
BACKUP="$TARGET/.volumio-v06-backup-$(date -u +%Y%m%d-%H%M%S)-$$"
mkdir -m 700 -- "$BACKUP"
FILES=(app.py music_agent.py volumio_api.py volumio_controller.py selections.py .env.companion)
for f in "${FILES[@]}"; do
  if [[ -f "$TARGET/$f" ]]; then cp -p -- "$TARGET/$f" "$BACKUP/$f";
  else : > "$BACKUP/$f.missing"; fi
done
ROLLBACK=1
rollback() {
  local rc=$?
  trap - ERR EXIT
  if (( ROLLBACK )); then
    echo "Installation fehlgeschlagen ($rc), Rollback aus $BACKUP" >&2
    for f in "${FILES[@]}"; do
      if [[ -e "$BACKUP/$f.missing" ]]; then rm -f -- "$TARGET/$f";
      else cp -p -- "$BACKUP/$f" "$TARGET/$f"; fi
    done
    systemctl --user restart "$SERVICE" || true
  fi
  rm -rf -- "$STAGE"
  exit "$rc"
}
trap rollback ERR EXIT
for f in app.py music_agent.py volumio_api.py volumio_controller.py selections.py; do
  install -m 0644 "$STAGE/$f" "$TARGET/$f"
done
"$TARGET/.venv/bin/python" - "$TARGET/.env.companion" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1]); lines = p.read_text().splitlines() if p.exists() else []
for key, value in [('VOLUMIO_ENABLED','1'),('VOLUMIO_URL','http://192.168.2.241')]:
    old = [s for s in lines if s.startswith(key+'=')]
    if key == 'VOLUMIO_ENABLED':
        lines = [s for s in lines if not s.startswith(key+'=')]
        lines.append(key+'='+value)
    elif not old:
        lines.append(key+'='+value)
p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
PY
systemctl --user restart "$SERVICE"
READY=0
for i in $(seq 1 "${COMPANION_INSTALL_RETRIES:-20}"); do
  if curl -fsS --max-time 2 http://127.0.0.1:8000/api/volumio/v06/capabilities 2>/dev/null \
      | "$TARGET/.venv/bin/python" -c 'import sys,json;x=json.load(sys.stdin);assert x["version"]=="0.6.0" and x["artist_play"] and x["track_selection"] and x["volumio_enabled"]' 2>/dev/null; then
    READY=1; break
  fi
  sleep 1
done
if (( ! READY )); then
  echo "v0.6 nicht geladen. Prüfe journalctl --user -u waveshare-companion -n 80" >&2
  false
fi
ROLLBACK=0
trap - ERR EXIT
rm -rf -- "$STAGE"
echo "Companion/Volumio v0.6 geladen. Backup: $BACKUP"
