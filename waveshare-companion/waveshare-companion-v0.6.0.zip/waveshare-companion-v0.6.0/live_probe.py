#!/usr/bin/env python3
"""Read-only playback probe (selection creation is local, never starts Volumio)."""
from __future__ import annotations
import argparse
import json
import urllib.parse
import urllib.request
import urllib.error

parser=argparse.ArgumentParser(description='Probe Volumio Artist Browse and selection API without playing music.')
parser.add_argument('--base',default='http://127.0.0.1:8000')
parser.add_argument('--artist',default='Daft Punk')
parser.add_argument('--search',default='Get Lucky')
args=parser.parse_args()
base=args.base.rstrip('/')

def call(path,*,body=None):
    data=None if body is None else json.dumps(body).encode('utf-8')
    req=urllib.request.Request(base+path,data=data,headers={'Content-Type':'application/json'} if data else {})
    try:
        with urllib.request.urlopen(req,timeout=20) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        print('HTTP',exc.code,exc.read().decode('utf-8','replace'));raise SystemExit(1)

caps=call('/api/volumio/v06/capabilities')
print('Backend:',caps)
assert caps.get('version')=='0.6.0', 'v0.6 nicht geladen'
assert caps.get('volumio_enabled'), 'Volumio deaktiviert'
artist_uri='/api/volumio/spotify/artist/preview?'+urllib.parse.urlencode({'artist':args.artist,'limit':20})
preview=call(artist_uri)
print('Künstler:',args.artist,'Quelle:',preview.get('source'),
      'teilweise:',preview.get('partial_results'), 'Titel:',preview.get('count'),
      'bereit:',preview.get('ready_to_play',False))
for i,t in enumerate(preview.get('tracks',[])[:20],1):
    print(f'{i:2d}. {t.get("title")!s} – {t.get("artist")!s}')
selection=call('/api/volumio/selections',body={'query':args.search})
print('Auswahl-ID:',selection['selection_id'],
      'Kandidaten:',len(selection.get('items',[])),
      'Ablauf:',selection['expires_at'])
for i,t in enumerate(selection.get('items',[]),1):
    print(f'{i:2d}. {t.get("title")} — {t.get("artist")} ({t.get("version")})')
print('Read-only-Test fertig. Keine Wiedergabe gestartet.')
