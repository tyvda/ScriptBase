#!/usr/bin/env python3
"""Strict, idempotent patch for v0.5.3+ Companion audio-worker.

Does NOT replace the original app.py wholesale. Fails without writing if the
expected hook was modified. No changes to firmware or audio codec paths.
"""
from __future__ import annotations

import ast
from pathlib import Path
import sys

MARKER = 'VOLUMIO_AUDIO_ROUTER_V060'
HOOK = '''{indent}# VOLUMIO_AUDIO_ROUTER_V060: persist selection UI in turn status.
{indent}music_result = music_agent.handle_voice_result(transcript)
{indent}if music_result is not None:
{indent}    if not update_if_active(turn_id, answer=music_result['answer'],
{indent}                            ui=music_result.get('ui'), state='speaking'):
{indent}        return
{indent}    pipeline.synthesize(music_result['answer'], folder / 'answer.wav')
{indent}    update_if_active(turn_id, state='ready')
{indent}    return
'''


def patch_app(source: str) -> str:
    module = ast.parse(source)
    funcs = [n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'work']
    turns = [n for n in module.body if isinstance(n, ast.ClassDef) and n.name == 'Turn']
    if len(funcs) != 1 or len(turns) != 1:
        raise RuntimeError('Erwarte exakt eine work()-Funktion und eine Turn-Dataclass')
    work, turn = funcs[0], turns[0]
    lines = source.splitlines(keepends=True)
    patches: list[tuple[int, int, list[str]]] = []

    if MARKER in source:
        if source.count(MARKER) != 1 or 'handle_voice_result(transcript)' not in ast.get_source_segment(source, work):
            raise RuntimeError('v0.6-Audio-Hook inkonsistent; keine Änderung')
    else:
        assign_nodes = [n for n in ast.walk(work) if isinstance(n, ast.Assign)
                        and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
                        and n.targets[0].id == 'music_answer'
                        and isinstance(n.value, ast.Call)
                        and isinstance(n.value.func, ast.Attribute)
                        and isinstance(n.value.func.value, ast.Name)
                        and n.value.func.value.id == 'music_agent'
                        and n.value.func.attr == 'handle_voice']
        if len(assign_nodes) != 1:
            raise RuntimeError('Alten v0.5.3-Musikhook in work() nicht eindeutig erkannt; nichts verändert')
        assign = assign_nodes[0]
        if_nodes = [n for n in ast.walk(work) if isinstance(n, ast.If)
                    and n.lineno == assign.end_lineno + 1
                    and isinstance(n.test, ast.Compare)
                    and isinstance(n.test.left, ast.Name)
                    and n.test.left.id == 'music_answer'
                    and len(n.test.ops) == 1 and isinstance(n.test.ops[0], ast.IsNot)]
        if len(if_nodes) != 1:
            raise RuntimeError('Alten Audio-Hook: if music_answer is not None nicht gefunden')
        branch = if_nodes[0]
        old = ''.join(lines[assign.lineno - 2:branch.end_lineno])
        if ('VOLUMIO_AUDIO_ROUTER_V053' not in old
                or 'pipeline.synthesize(music_answer' not in old
                or 'update_if_active(turn_id, state="ready")' not in old):
            raise RuntimeError('Unbekannter Audio-Hook. Keine Dateien verändern.')
        indent = lines[assign.lineno-1][:len(lines[assign.lineno-1])-len(lines[assign.lineno-1].lstrip())]
        # Remove from old marker through branch's last return, preserving all
        # surrounding transcribe, LLM, Piper and session logic.
        patches.append((assign.lineno-2, branch.end_lineno, HOOK.format(indent=indent).splitlines(keepends=True)))

    has_ui = any(isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)
                 and n.target.id == 'ui' for n in turn.body)
    if not has_ui:
        errors = [n for n in turn.body if isinstance(n, ast.AnnAssign)
                  and isinstance(n.target, ast.Name) and n.target.id == 'error']
        if len(errors) != 1:
            raise RuntimeError('Turn.error nicht eindeutig gefunden; keine Dateien verändern')
        line_no = errors[0].end_lineno
        indent = lines[line_no-1][:len(lines[line_no-1])-len(lines[line_no-1].lstrip())]
        patches.append((line_no, line_no, [indent+'ui: dict | None = None\n']))

    # Apply from bottom so AST line indices remain valid.
    for start, end, replacement in sorted(patches, reverse=True):
        lines[start:end] = replacement
    updated = ''.join(lines)
    if 'app.version = "0.6.0"' not in updated:
        updated += '\n# API extension; all existing HTTP paths remain backward compatible.\napp.version = "0.6.0"\n'
    compile(updated, '<companion-app-patched>', 'exec')
    assert updated.count(MARKER) == 1
    return updated


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python patch_backend.py /path/to/server/app.py')
    f = Path(sys.argv[1])
    original = f.read_text(encoding='utf-8')
    patched = patch_app(original)
    f.write_text(patched, encoding='utf-8')
    print('Audio-Worker v0.6 und Turn.ui aktiviert')
