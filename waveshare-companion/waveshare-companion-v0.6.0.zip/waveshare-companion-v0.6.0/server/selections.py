"""Bounded, in-memory, time-limited interactive Spotify choice sessions.

An opaque candidate_id maps to a previously validated Volumio result. Clients
never send a service URI or playback payload to the confirmation endpoint.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import secrets
import threading
import time

from volumio_controller import Track, SPOTIFY_SERVICES, PLAYABLE_TYPES, VolumioClient

TTL_SECONDS = 120
MAX_SESSIONS = 32
MAX_CANDIDATES = 8


class SelectionError(Exception):
    status = 404


class SelectionNotFound(SelectionError):
    status = 404


class SelectionExpired(SelectionError):
    status = 410


class SelectionConflict(SelectionError):
    status = 409


@dataclass
class _Entry:
    query: str
    created: float
    expires_wall: float
    items: dict[str, Track]
    busy: bool = False
    consumed: bool = False


_lock = threading.RLock()
_sessions: dict[str, _Entry] = {}


def _purge(now: float) -> None:
    # Expired entries are retained briefly so clients receive 410, not 404.
    for key, entry in list(_sessions.items()):
        if now - entry.created > TTL_SECONDS + 120:
            _sessions.pop(key, None)
    if len(_sessions) >= MAX_SESSIONS:
        removable = sorted(((k, v) for k, v in _sessions.items() if not v.busy),
                           key=lambda x: x[1].created)
        for k, _ in removable[:len(_sessions)-MAX_SESSIONS+1]:
            _sessions.pop(k, None)


def _view(selection_id: str, item: _Entry) -> dict:
    return {
        'type': 'track_selection',
        'selection_id': selection_id,
        'query': item.query,
        'expires_at': datetime.fromtimestamp(item.expires_wall, tz=timezone.utc).isoformat(),
        'items': [
            {'candidate_id': cid, 'title': t.title, 'artist': t.artist,
             'album': t.album, 'albumart': t.albumart, 'version': _version(t.title)}
            for cid, t in item.items.items()
        ],
    }


def _version(title: str) -> str:
    import re
    for variant in ('Radio Edit', 'Remix', 'Live', 'Acoustic', 'Remaster', 'Drumless'):
        if re.search(r'\b' + re.escape(variant) + r'\b', title, flags=re.I):
            return variant
    return 'Standard'


def create(query: str, candidates: list[dict]) -> dict:
    tracks: dict[str, Track] = {}
    seen = set()
    for item in candidates:
        if len(tracks) == MAX_CANDIDATES:
            break
        try:
            t = Track(**{field: item.get(field, '') for field in Track.__dataclass_fields__})
        except (TypeError, ValueError):
            continue
        if t.type not in PLAYABLE_TYPES or t.service not in SPOTIFY_SERVICES or not t.uri.startswith('spotify:track:'):
            continue
        if t.uri in seen:
            continue
        seen.add(t.uri)
        tracks[secrets.token_hex(6)] = t
    if not tracks:
        raise ValueError('Keine wählbaren Spotify-Titel')
    with _lock:
        now = time.monotonic()
        _purge(now)
        sid = secrets.token_urlsafe(18)
        entry = _Entry(query=query[:120], created=now, expires_wall=time.time()+TTL_SECONDS, items=tracks)
        _sessions[sid] = entry
        return _view(sid, entry)


def get(selection_id: str) -> dict:
    with _lock:
        entry = _sessions.get(selection_id)
        if entry is None:
            raise SelectionNotFound('Unbekannte Auswahl')
        if time.monotonic() - entry.created >= TTL_SECONDS:
            raise SelectionExpired('Auswahl abgelaufen')
        if entry.consumed or entry.busy:
            raise SelectionConflict('Auswahl bereits bestätigt')
        return _view(selection_id, entry)


def confirm(selection_id: str, candidate_id: str, client: VolumioClient) -> dict:
    with _lock:
        entry = _sessions.get(selection_id)
        if entry is None:
            raise SelectionNotFound('Unbekannte Auswahl')
        if time.monotonic() - entry.created >= TTL_SECONDS:
            raise SelectionExpired('Auswahl abgelaufen')
        if entry.busy or entry.consumed:
            raise SelectionConflict('Auswahl bereits bestätigt')
        item = entry.items.get(candidate_id)
        if item is None:
            raise SelectionNotFound('Unbekannter Kandidat')
        # Reserve before sending an irreversible command. Retrying an uncertain
        # network timeout must never trigger another replaceAndPlay blindly.
        entry.busy = True
        entry.consumed = True
    response = client._post('/api/v1/replaceAndPlay', item.as_dict())
    return {'accepted': True, 'selection_id': selection_id,
            'candidate_id': candidate_id,
            'track': {'title': item.title, 'artist': item.artist, 'album': item.album},
            'message': f'Wiedergabe von {item.title} von {item.artist} angefordert.',
            'ack': response}


def cancel(selection_id: str) -> dict:
    with _lock:
        item = _sessions.get(selection_id)
        if item is None:
            raise SelectionNotFound('Unbekannte Auswahl')
        if item.busy or item.consumed:
            raise SelectionConflict('Auswahl bereits bestätigt')
        item.consumed = True
    return {'cancelled': True, 'selection_id': selection_id}
