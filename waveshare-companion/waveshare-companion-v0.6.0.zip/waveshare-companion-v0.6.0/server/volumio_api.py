"""Optional Volumio REST API endpoints mounted into the existing FastAPI server."""
from __future__ import annotations

import os
from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from volumio_controller import VolumioClient, VolumioError
from music_agent import Intent, execute_intent, handle_voice_result
import selections

router = APIRouter(prefix='/api/volumio', tags=['Volumio'])


@router.get('/v06/capabilities')
def v06_capabilities():
    return {'version': '0.6.0', 'artist_play': True, 'track_selection': True,
            'selection_ttl_seconds': selections.TTL_SECONDS,
            'max_selection_items': selections.MAX_CANDIDATES,
            'volumio_enabled': os.getenv('VOLUMIO_ENABLED', '0').casefold() in ('1','true','yes')}


class ControlRequest(BaseModel):
    action: Literal['play', 'pause', 'stop', 'next', 'prev', 'toggle',
                    'volume', 'volume_up', 'volume_down', 'mute', 'unmute', 'status']
    volume: int | None = Field(default=None, ge=0, le=100)


class SpotifyPlayRequest(BaseModel):
    query: str = Field(min_length=3, max_length=120)


class VoiceRequest(BaseModel):
    text: str = Field(min_length=1, max_length=300)


class ArtistRequest(BaseModel):
    artist: str = Field(min_length=2, max_length=100)
    limit: int = Field(default=20, ge=2, le=20)


class SelectionRequest(BaseModel):
    query: str = Field(min_length=3, max_length=120)


class SelectRequest(BaseModel):
    candidate_id: str = Field(min_length=1, max_length=64)


def _enabled():
    if os.getenv('VOLUMIO_ENABLED', '0').casefold() not in ('1', 'true', 'yes'):
        raise HTTPException(status_code=503, detail='Volumio-Integration deaktiviert')


def _client() -> VolumioClient:
    return VolumioClient(timeout=float(os.getenv('VOLUMIO_TIMEOUT', '5')))


def _run(fn):
    try:
        return fn()
    except VolumioError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get('/status')
def status():
    _enabled()
    return _run(lambda: _client().state())


@router.get('/sources')
def sources():
    _enabled()
    return _run(lambda: _client().browse_sources())


@router.get('/spotify/search')
def spotify_search(query: str = Query(min_length=3, max_length=120), limit: int = Query(default=8, ge=1, le=20)):
    _enabled()
    return _run(lambda: _client().spotify_search(query, limit))


@router.post('/spotify/play')
def spotify_play(payload: SpotifyPlayRequest):
    _enabled()
    return _run(lambda: _client().spotify_play(payload.query))


@router.post('/control')
def control(payload: ControlRequest):
    _enabled()
    return _run(lambda: execute_intent(
        Intent(action=payload.action, value=payload.volume), _client()))


@router.post('/voice')
def voice(payload: VoiceRequest):
    _enabled()
    try:
        result = handle_voice_result(payload.text)
    except Exception as exc:
        raise HTTPException(status_code=502, detail='Fehler bei der Sprachverarbeitung') from exc
    return {'handled': result is not None, 'answer': result['answer'] if result else None,
            'action': result.get('action') if result else None,
            'ui': result.get('ui') if result else None}


@router.post('/spotify/artist/play')
def artist_play(payload: ArtistRequest):
    _enabled()
    return _run(lambda: _client().spotify_artist_play(payload.artist, limit=payload.limit))


@router.get('/spotify/artist/preview')
def artist_preview(artist: str = Query(min_length=2, max_length=100),
                   limit: int = Query(default=20, ge=2, le=20)):
    _enabled()
    return _run(lambda: _client().spotify_artist_preview(artist, limit=limit))


@router.post('/selections', status_code=201)
def new_selection(payload: SelectionRequest):
    _enabled()
    def _make():
        result = _client().spotify_search(payload.query, limit=20)
        return selections.create(payload.query, result['candidates'])
    return _run(_make)


def _selection_error(exc: selections.SelectionError) -> HTTPException:
    return HTTPException(status_code=exc.status, detail=str(exc))


@router.get('/selections/{selection_id}')
def get_selection(selection_id: str):
    _enabled()
    try:
        return selections.get(selection_id)
    except selections.SelectionError as exc:
        raise _selection_error(exc) from exc


@router.post('/selections/{selection_id}/play')
def play_selection(selection_id: str, payload: SelectRequest):
    _enabled()
    try:
        return _run(lambda: selections.confirm(selection_id, payload.candidate_id, _client()))
    except selections.SelectionError as exc:
        raise _selection_error(exc) from exc


@router.delete('/selections/{selection_id}')
def cancel_selection(selection_id: str):
    _enabled()
    try:
        return selections.cancel(selection_id)
    except selections.SelectionError as exc:
        raise _selection_error(exc) from exc
