from pathlib import Path
import os
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

from test_v06 import BASE

ROOT=Path(__file__).resolve().parents[1]

class InstallTests(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root=Path(self.temp.name)
        self.target=root/'server';self.target.mkdir()
        (self.target/'.venv/bin').mkdir(parents=True)
        wrapper=self.target/'.venv/bin/python'
        wrapper.write_text('#!/bin/sh\nexec '+sys.executable+' "$@"\n')
        wrapper.chmod(0o755)
        (self.target/'app.py').write_text(BASE)
        (self.target/'pipeline.py').write_text('def transcribe(x): return "hallo"\n')
        (self.target/'.env.companion').write_text('OLLAMA_MODEL=test\nVOLUMIO_URL=http://192.168.2.241\n')
        self.bin=root/'fakebin';self.bin.mkdir()
        (self.bin/'systemctl').write_text('#!/bin/sh\nexit 0\n')
        (self.bin/'systemctl').chmod(0o755)
        self.env=os.environ.copy()
        self.env['PATH']=str(self.bin)+os.pathsep+self.env['PATH']
        self.env['COMPANION_INSTALL_RETRIES']='1'
        self.old=self.target.joinpath('app.py').read_bytes()

    def invoke(self, curl_result):
        (self.bin/'curl').write_text('#!/bin/sh\n'+curl_result+'\n')
        (self.bin/'curl').chmod(0o755)
        return subprocess.run(['bash',str(ROOT/'install.sh'),str(self.target)],
                              cwd=self.temp.name,env=self.env,capture_output=True,text=True,timeout=15)

    def test_install_and_idempotent(self):
        answer='echo \'{"version":"0.6.0","artist_play":true,"track_selection":true,"volumio_enabled":true}\''
        out=self.invoke(answer)
        self.assertEqual(out.returncode,0,out.stdout+out.stderr)
        s=self.target.joinpath('app.py').read_text()
        self.assertIn('VOLUMIO_AUDIO_ROUTER_V060',s)
        self.assertIn('ui: dict | None = None',s)
        self.assertEqual(s.count('VOLUMIO_AUDIO_ROUTER_V060'),1)
        self.assertIn('VOLUMIO_ENABLED=1',(self.target/'.env.companion').read_text())
        self.assertEqual(self.invoke(answer).returncode,0)
        self.assertEqual(self.target.joinpath('app.py').read_text().count('VOLUMIO_AUDIO_ROUTER_V060'),1)

    def test_bad_live_check_restores_original(self):
        out=self.invoke('exit 7')
        self.assertNotEqual(out.returncode,0)
        self.assertEqual(self.old,(self.target/'app.py').read_bytes())
        self.assertFalse((self.target/'selections.py').exists())
        self.assertEqual((self.target/'.env.companion').read_text(),
                         'OLLAMA_MODEL=test\nVOLUMIO_URL=http://192.168.2.241\n')

if __name__=='__main__':unittest.main()
