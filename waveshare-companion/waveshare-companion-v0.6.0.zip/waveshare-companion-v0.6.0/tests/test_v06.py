import os
from pathlib import Path
import sys
from types import ModuleType
import unittest
from unittest.mock import patch, Mock

import httpx
from fastapi import FastAPI
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT))
from volumio_controller import VolumioClient
from music_agent import Intent, parse_voice, execute_intent, handle_voice_result
import selections
import volumio_api
from patch_backend import patch_app


def song(title, artist='Daft Punk', uri=None, album='Random Access Memories'):
    return {'type':'song','service':'spop','title': title, 'artist':artist,
            'album':album, 'uri':uri or 'spotify:track:'+title.replace(' ','_'),
            'albumart':'https://i.scdn.co/image/abc'}


def group(*items):
    return {'navigation':{'lists':[{'items':list(items)}]}}


class FakeVolumio:
    def __init__(self, *, with_artist=True, with_browse=True):
        self.calls=[]
        self.with_artist=with_artist
        self.with_browse=with_browse

    def handler(self, req):
        path=req.url.path
        self.calls.append((req.method,path,dict(req.url.params),req.content))
        if path.endswith('/search'):
            tracks = [song('Get Lucky'), song('One More Time'), song('Harder Better Faster Stronger'),
                      song('Get Lucky (Radio Edit)',uri='spotify:track:radio'), song('Get Lucky','Daft Punk Tribute','spotify:track:tribute')]
            if self.with_artist:
                tracks.insert(0,{'title':'Daft Punk','service':'spop','type':'folder','uri':'spotify:artist:123'})
            return httpx.Response(200,json=group(*tracks))
        if path.endswith('/browse'):
            uri=req.url.params.get('uri')
            if not self.with_browse:
                return httpx.Response(404,json={'detail':'no browse'})
            if uri=='spotify:artist:123':
                return httpx.Response(200,json=group({'title':'Random Access Memories','type':'folder','service':'spop','uri':'spotify:album:123'}))
            if uri=='spotify:album:123':
                return httpx.Response(200,json=group(song('Get Lucky'),song('One More Time'),
                    song('Harder Better Faster Stronger'),song('Get Lucky (Radio Edit)',uri='spotify:track:radio'),
                    song('Get Lucky','Daft Punk Tribute','spotify:track:tribute')))
            return httpx.Response(200,json=group())
        if path.endswith('/replaceAndPlay'):
            return httpx.Response(200,json={'success':True})
        return httpx.Response(404,json={})


class ArtistTests(unittest.TestCase):
    def test_artist_queue_artist_exact_dedup_randomized(self):
        mock=FakeVolumio()
        client=VolumioClient('http://192.168.2.241',transport=httpx.MockTransport(mock.handler))
        out=client.spotify_artist_play('Daft Punk',limit=20)
        self.assertTrue(out['accepted'])
        self.assertEqual(out['source'],'artist_browse')
        self.assertEqual(out['count'],3)
        calls=[c for c in mock.calls if c[1].endswith('replaceAndPlay')]
        self.assertEqual(len(calls),1)
        import json
        body=json.loads(calls[0][3])
        self.assertEqual(len(body['list']),3)
        self.assertEqual(body['item'],body['list'][0])
        self.assertNotIn('Daft Punk Tribute',[t['artist'] for t in body['list']])
        self.assertEqual(set(t['title'] for t in body['list']), {'Get Lucky','One More Time','Harder Better Faster Stronger'})

    def test_search_fallback_partial(self):
        mock=FakeVolumio(with_artist=False)
        client=VolumioClient('http://192.168.2.241',transport=httpx.MockTransport(mock.handler))
        out=client.spotify_artist_play('Daft Punk')
        self.assertTrue(out['accepted'])
        self.assertTrue(out['partial_results'])
        self.assertEqual(out['source'],'search_fallback')

    def test_artist_missing_no_queue(self):
        mock=FakeVolumio()
        client=VolumioClient('http://192.168.2.241',transport=httpx.MockTransport(mock.handler))
        out=client.spotify_artist_play('Depeche Mode')
        self.assertFalse(out['accepted'])
        self.assertFalse(any(c[1].endswith('replaceAndPlay') for c in mock.calls))

    def test_invalid_artist_and_limit(self):
        mock=FakeVolumio()
        client=VolumioClient(transport=httpx.MockTransport(mock.handler))
        for artist in ('', 'x'):
            with self.assertRaises(ValueError):client.spotify_artist_play(artist)
        with self.assertRaises(ValueError):client.spotify_artist_play('Daft Punk',limit=1)


class VoiceTests(unittest.TestCase):
    def test_artist_speech_variants(self):
        for s in ('Spiele Musik von Daft Punk','Spiel etwas von Daft Punk','Spiele Songs von Daft Punk auf Spotify'):
            out=parse_voice(s)
            self.assertEqual(out.action,'artist_play',s)
            self.assertEqual(out.query,'daft punk')
        self.assertEqual(parse_voice('Spiele Daft Punk').action,'artist_or_song')
        self.assertEqual(parse_voice('Spiele Get Lucky von Daft Punk').action,'spotify_play')
        self.assertEqual(parse_voice('Was läuft gerade?').action,'status')
        self.assertIsNone(parse_voice('Was ist elektronische Musik?'))

    def test_ambiguous_creates_ui_without_play(self):
        class MockClient:
            def spotify_play(self,q):
                return {'accepted':False,'reason':'ambiguous','message':'ambiguous','candidates':[
                    song('Get Lucky'),song('Get Lucky (Radio Edit)',uri='spotify:track:radio')]}
        out=execute_intent(Intent('spotify_play',query='Get Lucky'),MockClient())
        self.assertIn('ui',out)
        self.assertEqual(out['ui']['type'],'track_selection')
        self.assertEqual(len(out['ui']['items']),2)
        self.assertTrue(out['answer'].startswith('Ich habe mehrere'))

    def test_artist_voice_and_regular_llm(self):
        with patch.dict(os.environ,{'VOLUMIO_ENABLED':'1'}),\
             patch('music_agent.VolumioClient') as factory:
            factory.return_value.spotify_artist_play.return_value={'accepted':True,'message':'Ich spiele 10 Songs.'}
            self.assertEqual(handle_voice_result('Spiele Musik von Daft Punk')['action'],'artist_play')
            self.assertIsNone(handle_voice_result('Wie ist das Wetter?'))


class SelectionTests(unittest.TestCase):
    def setUp(self):
        with selections._lock:selections._sessions.clear()

    def test_choose_opaque_ids_only_once(self):
        ui=selections.create('Get Lucky',[song('Get Lucky'),song('Get Lucky (Radio Edit)',uri='spotify:track:radio')])
        self.assertEqual(ui['type'],'track_selection')
        self.assertNotIn('uri',ui['items'][0]);self.assertNotIn('spotify:',str(ui))
        mock=FakeVolumio()
        client=VolumioClient(transport=httpx.MockTransport(mock.handler))
        cid=ui['items'][1]['candidate_id']
        out=selections.confirm(ui['selection_id'],cid,client)
        self.assertTrue(out['accepted'])
        self.assertEqual(len([c for c in mock.calls if c[1].endswith('replaceAndPlay')]),1)
        with self.assertRaises(selections.SelectionConflict):
            selections.confirm(ui['selection_id'],cid,client)

    def test_unknown_candidate_does_not_consume(self):
        ui=selections.create('Get Lucky',[song('Get Lucky')])
        mock=FakeVolumio();client=VolumioClient(transport=httpx.MockTransport(mock.handler))
        with self.assertRaises(selections.SelectionNotFound):
            selections.confirm(ui['selection_id'],'bad',client)
        self.assertEqual(selections.get(ui['selection_id'])['type'],'track_selection')
        self.assertFalse(mock.calls)

    def test_expiry(self):
        ui=selections.create('Get Lucky',[song('Get Lucky')])
        with patch.object(selections.time,'monotonic',return_value=selections._sessions[ui['selection_id']].created+121):
            with self.assertRaises(selections.SelectionExpired):selections.get(ui['selection_id'])

    def test_invalid_uri_discard(self):
        with self.assertRaises(ValueError):
            selections.create('hack',[{**song('Bad'), 'uri':'http://attacker/'}])

    def test_endpoint_selection(self):
        app=FastAPI();app.include_router(volumio_api.router)
        client=TestClient(app)
        with patch.dict(os.environ,{'VOLUMIO_ENABLED':'1'}),\
             patch('volumio_api._client') as fac:
            fac.return_value.spotify_search.return_value={'candidates':[song('Get Lucky'),song('Get Lucky Remix',uri='spotify:track:remix')]}
            fac.return_value._post.return_value={'success':True}
            self.assertEqual(client.get('/api/volumio/v06/capabilities').json()['version'],'0.6.0')
            make=client.post('/api/volumio/selections',json={'query':'Get Lucky'})
            self.assertEqual(make.status_code,201)
            ui=make.json(); sid=ui['selection_id']
            self.assertEqual(client.get('/api/volumio/selections/'+sid).status_code,200)
            cid=ui['items'][0]['candidate_id']
            self.assertEqual(client.post('/api/volumio/selections/'+sid+'/play',json={'candidate_id':cid}).status_code,200)
            self.assertEqual(client.post('/api/volumio/selections/'+sid+'/play',json={'candidate_id':cid}).status_code,409)
            self.assertEqual(fac.return_value._post.call_count,1)


BASE='''from dataclasses import dataclass, field\nfrom pathlib import Path\nfrom fastapi import FastAPI\nimport music_agent\nimport pipeline\napp = FastAPI(version="0.4.1")\n@dataclass\nclass Turn:\n    id: str\n    error: str = ""\n    created_at: str = "abc"\ndef update_if_active(*args, **kwargs):\n    return True\ndef work(turn_id):\n    folder = Path('/tmp')\n    transcript = pipeline.transcribe(folder / "input.wav")\n    if not update_if_active(turn_id, transcript=transcript, state="thinking"):\n        return\n    # VOLUMIO_AUDIO_ROUTER_V053: intercept music directly in the WAV job.\n    music_answer = music_agent.handle_voice(transcript)\n    if music_answer is not None:\n        if not update_if_active(turn_id, answer=music_answer, state="speaking"):\n            return\n        pipeline.synthesize(music_answer, folder / "answer.wav")\n        update_if_active(turn_id, state="ready")\n        return\n    answer = pipeline.generate_answer(transcript)\n    pipeline.synthesize(answer, folder / "answer.wav")\n'''

class PatchTests(unittest.TestCase):
    def test_patch_idempotent_and_preserves_llm(self):
        src=patch_app(BASE)
        self.assertEqual(src.count('VOLUMIO_AUDIO_ROUTER_V060'),1)
        self.assertIn('ui: dict | None = None',src)
        self.assertIn("music_agent.handle_voice_result(transcript)",src)
        self.assertIn('pipeline.generate_answer(transcript)',src)
        self.assertEqual(patch_app(src),src)

    def test_unknown_worker_fails_closed(self):
        with self.assertRaises(RuntimeError):patch_app(BASE.replace('music_answer = music_agent.handle_voice(transcript)','foo=123'))

    def test_audio_worker_selection_reaches_status_without_ollama(self):
        namespace={}
        fake_pipeline=ModuleType('pipeline')
        with patch.dict(sys.modules,{'pipeline':fake_pipeline}):
            exec(compile(patch_app(BASE),'<v06>', 'exec'),namespace)
        update=Mock(return_value=True)
        namespace['update_if_active']=update
        ui={'type':'track_selection','selection_id':'opaque', 'items':[]}
        with patch.object(fake_pipeline,'transcribe',return_value='Spiele Get Lucky',create=True), \
             patch('music_agent.handle_voice_result',return_value={'answer':'Wähle einen Song','ui':ui}), \
             patch.object(fake_pipeline,'generate_answer',create=True) as ollama, \
             patch.object(fake_pipeline,'synthesize',create=True) as piper:
            namespace['work']('uuid')
            ollama.assert_not_called()
            piper.assert_called_once()
        self.assertTrue(any(c.kwargs.get('ui')==ui for c in update.call_args_list))

    def test_audio_worker_non_music_uses_ollama(self):
        namespace={};fake_pipeline=ModuleType('pipeline')
        with patch.dict(sys.modules,{'pipeline':fake_pipeline}):
            exec(compile(patch_app(BASE),'<v06>','exec'),namespace)
        with patch.object(fake_pipeline,'transcribe',return_value='Was ist Python?',create=True), \
             patch('music_agent.handle_voice_result',return_value=None), \
             patch.object(fake_pipeline,'generate_answer',return_value='Eine Sprache',create=True) as ollama, \
             patch.object(fake_pipeline,'synthesize',create=True) as piper:
            namespace['work']('uuid')
            ollama.assert_called_once()
            piper.assert_called_once()

if __name__=='__main__':unittest.main()
