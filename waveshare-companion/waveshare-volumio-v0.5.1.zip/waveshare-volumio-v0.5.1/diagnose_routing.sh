#!/usr/bin/env bash
# Non-destructive diagnosis of Volumio speech routing on Ubuntu.
set -u
TARGET="${1:-/srv/ai/projects/companion-mvp/server}"
BASE="${2:-http://127.0.0.1:8000}"
printf '\n== Local files ==\n'
for p in app.py pipeline.py music_agent.py volumio_api.py .env.companion; do
    [[ -f "$TARGET/$p" ]] && echo "OK: $p" || echo "MISSING: $p"
done
printf '\n== Volumio settings in file ==\n'
if [[ -f "$TARGET/.env.companion" ]]; then
    grep -E '^VOLUMIO_(ENABLED|URL|TIMEOUT)=' "$TARGET/.env.companion" || true
fi
printf '\n== Source hook ==\n'
grep -n 'from music_agent import handle_voice\|music_answer = handle_voice' "$TARGET/pipeline.py" 2>/dev/null || true
printf '\n== systemd ==\n'
systemctl --user show waveshare-companion -p ActiveState -p MainPID --no-pager 2>/dev/null || true
printf '\n== Backend /health ==\n'
curl -sS -i --max-time 5 "$BASE/health" | head -c 400; printf '\n'
printf '\n== Volumio REST status, read-only ==\n'
curl -sS -i --max-time 10 "$BASE/api/volumio/status" | head -c 750; printf '\n'
printf '\n== Volumio voice routing, read-only ==\n'
curl -sS -i --max-time 12 -H 'Content-Type: application/json' -d '{"text":"Was läuft gerade?"}' "$BASE/api/volumio/voice" | head -c 850; printf '\n'
