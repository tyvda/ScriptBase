#!/usr/bin/env bash
# Addon for existing Waveshare Companion v0.4.1. No sudo needed for user service.
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-/srv/ai/projects/companion-mvp/server}"
if [[ ! -f "$TARGET/app.py" || ! -f "$TARGET/pipeline.py" ]]; then
  echo "Companion-Backend nicht gefunden: $TARGET" >&2; exit 2
fi
BACKUP="$TARGET/.volumio-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp "$TARGET/app.py" "$TARGET/pipeline.py" "$BACKUP/"
if [[ -f "$TARGET/.env.companion" ]]; then cp "$TARGET/.env.companion" "$BACKUP/"; fi
rollback() {
  echo "Installation fehlgeschlagen – stelle app.py und pipeline.py wieder her" >&2
  cp "$BACKUP/app.py" "$TARGET/app.py"
  cp "$BACKUP/pipeline.py" "$TARGET/pipeline.py"
  [[ ! -f "$BACKUP/.env.companion" ]] || cp "$BACKUP/.env.companion" "$TARGET/.env.companion"
}
trap rollback ERR
cp "$SCRIPT_DIR/server/volumio_controller.py" "$SCRIPT_DIR/server/music_agent.py" "$SCRIPT_DIR/server/volumio_api.py" "$TARGET/"
python3 "$SCRIPT_DIR/install_patch.py" "$TARGET"
python3 -m py_compile "$TARGET/app.py" "$TARGET/pipeline.py" "$TARGET/volumio_controller.py" "$TARGET/music_agent.py" "$TARGET/volumio_api.py"
ENVFILE="$TARGET/.env.companion"
touch "$ENVFILE"
# This addon was explicitly requested for the local Volumio host. Enforce
# activation even when a previous installation left VOLUMIO_ENABLED=0.
python3 - "$ENVFILE" <<'PYENV'
from pathlib import Path
import sys
p = Path(sys.argv[1])
text = p.read_text(encoding='utf-8')
lines = text.splitlines()
for key, value in (
    ('VOLUMIO_ENABLED', '1'),
    ('VOLUMIO_URL', 'http://192.168.2.241'),
    ('VOLUMIO_TIMEOUT', '5'),
):
    indices = [i for i, line in enumerate(lines) if line.startswith(key + '=')]
    if indices:
        lines[indices[0]] = key + '=' + value
        for i in reversed(indices[1:]):
            del lines[i]
    else:
        lines.append(key + '=' + value)
p.write_text('\n'.join(lines) + '\n', encoding='utf-8')
PYENV
# Validate module hook and parser before restarting systemd.
if ! grep -q 'from music_agent import handle_voice' "$TARGET/pipeline.py"; then
  echo 'Volumio-Hook in pipeline.py fehlt' >&2
  exit 3
fi
"$TARGET/.venv/bin/python" - "$TARGET" <<'PYTEST'
from pathlib import Path
import sys
sys.path.insert(0, sys.argv[1])
import music_agent
assert music_agent.parse_voice('Was läuft gerade?').action == 'status'
print('Routing-Test: Was läuft gerade? -> Volumio status')
PYTEST
trap - ERR
if systemctl --user list-unit-files waveshare-companion.service --no-legend 2>/dev/null | grep -q waveshare-companion; then
  systemctl --user restart waveshare-companion.service
  echo 'systemd waveshare-companion neugestartet'
else
  echo 'Kein systemd User-Service gefunden – starte den bestehenden Uvicorn-Prozess manuell neu.'
fi
echo "Volumio-Modul installiert. Backup: $BACKUP"
