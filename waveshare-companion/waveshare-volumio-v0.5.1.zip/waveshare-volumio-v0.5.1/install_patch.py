"""Idempotently patch existing Companion v0.4.1 FastAPI and pipeline modules.

It deliberately does not replace the original speech processing code or change
any existing WAV, sessions, SSE or job paths.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys


def patch_server(app_path: Path, pipeline_path: Path) -> None:
    app = app_path.read_text(encoding='utf-8')
    if 'import volumio_api' not in app:
        if 'import pipeline\n' not in app:
            raise RuntimeError('app.py: import pipeline anchor missing; no changes made')
        app = app.replace('import pipeline\n', 'import pipeline\nimport volumio_api\n', 1)
    if 'app.include_router(volumio_api.router)' not in app:
        pattern = r'(^app\s*=\s*FastAPI\([^\n]*\)\s*$)'
        if not re.search(pattern, app, re.M):
            raise RuntimeError('app.py: FastAPI anchor missing; no changes made')
        app = re.sub(pattern, r'\1\napp.include_router(volumio_api.router)', app, count=1, flags=re.M)

    pipeline = pipeline_path.read_text(encoding='utf-8')
    if 'from music_agent import handle_voice' not in pipeline:
        anchor = '    """Use Ollama; the optional session history is bounded by the API layer."""\n'
        if anchor not in pipeline:
            raise RuntimeError('pipeline.py: answer function anchor missing; no changes made')
        inject = (anchor +
                  '    from music_agent import handle_voice\n'
                  '    music_answer = handle_voice(user_text)\n'
                  '    if music_answer is not None:\n'
                  '        return music_answer\n')
        pipeline = pipeline.replace(anchor, inject, 1)
    compile(app, str(app_path), 'exec')
    compile(pipeline, str(pipeline_path), 'exec')
    app_path.write_text(app, encoding='utf-8')
    pipeline_path.write_text(pipeline, encoding='utf-8')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: python install_patch.py <companion-mvp/server>')
    folder = Path(sys.argv[1])
    patch_server(folder/'app.py', folder/'pipeline.py')
