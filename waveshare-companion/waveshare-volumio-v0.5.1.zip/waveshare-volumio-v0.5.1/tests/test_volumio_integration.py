"""Integration tests using a simulated Volumio HTTP server (no LAN access needed)."""
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import httpx
from fastapi import FastAPI
from fastapi.testclient import TestClient

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / 'server'))
sys.path.insert(0, str(BASE))

import music_agent
import volumio_api
from volumio_controller import VolumioClient, VolumioError, VolumioUnavailable
from install_patch import patch_server


SPOTIFY_ITEM = {'service': 'spop', 'type': 'song', 'title': 'Get Lucky',
                'artist': 'Daft Punk', 'album': 'Random Access Memories',
                'uri': 'spotify:track:2Foc5Q5nqNiosCNqttzHof'}


class MockVolumio:
    def __init__(self):
        self.requests = []
        self.state = {'status': 'play', 'title': 'Get Lucky', 'artist': 'Daft Punk',
                      'volume': 42, 'service': 'spop'}
        self.search_items = [SPOTIFY_ITEM, {'service': 'mpd', 'type': 'song',
                           'title': 'Local', 'uri': 'music-library/x'}]
        self.fail = False

    def handle(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        if self.fail:
            return httpx.Response(503, json={'detail': 'offline'})
        path = request.url.path
        if path.endswith('/getState'):
            return httpx.Response(200, json=self.state)
        if path.endswith('/commands/'):
            return httpx.Response(200, json={'response': 'success'})
        if path.endswith('/search'):
            return httpx.Response(200, json={'navigation': {'lists': [{'items': self.search_items}]}})
        if path.endswith('/browse'):
            return httpx.Response(200, json={'navigation': {'lists': [{'name':'Spotify', 'uri':'spotify'}]}})
        if path.endswith('/replaceAndPlay'):
            return httpx.Response(200, json={'response': 'success'})
        return httpx.Response(404, json={'detail': 'unknown'})

    def client(self):
        return VolumioClient('http://192.168.2.241', transport=httpx.MockTransport(self.handle))


class VolumioHTTPTests(unittest.TestCase):
    def setUp(self):
        self.server = MockVolumio()
        self.c = self.server.client()

    def test_read_state(self):
        state = self.c.state()
        self.assertEqual(state['title'], 'Get Lucky')
        self.assertEqual(str(self.server.requests[-1].url), 'http://192.168.2.241/api/v1/getState')

    def test_player_commands_whitelist_and_parameter_encoding(self):
        for action in ('play', 'pause', 'stop', 'prev', 'next', 'toggle'):
            self.assertTrue(self.c.command(action)['accepted'])
        self.assertEqual([r.url.params['cmd'] for r in self.server.requests],
                         ['play', 'pause', 'stop', 'prev', 'next', 'toggle'])
        with self.assertRaises(ValueError):
            self.c.command('reboot')
        self.assertEqual(len(self.server.requests), 6)

    def test_volume_absolute_relative_and_bounds(self):
        self.c.set_volume(30)
        self.assertEqual(self.server.requests[-1].url.params['volume'], '30')
        self.assertEqual(self.c.change_volume(-10)['volume'], 32)
        self.assertEqual(self.c.change_volume(100)['volume'], 100)
        for invalid in (-1, 101, True):
            with self.assertRaises(ValueError):
                self.c.set_volume(invalid)

    def test_mute(self):
        self.c.mute(True)
        self.assertEqual(self.server.requests[-1].url.params['volume'], 'mute')
        self.c.mute(False)
        self.assertEqual(self.server.requests[-1].url.params['volume'], 'unmute')

    def test_spotify_search_filters_local_tracks(self):
        result = self.c.spotify_search('Get Lucky Daft Punk')
        self.assertEqual(len(result['candidates']), 1)
        self.assertEqual(result['candidates'][0]['service'], 'spop')
        self.assertEqual(self.server.requests[-1].url.params['query'], 'Get Lucky Daft Punk')

    def test_play_from_real_search_result_not_invented_uri(self):
        result = self.c.spotify_play('Get Lucky Daft Punk')
        self.assertTrue(result['accepted'])
        self.assertEqual([r.method for r in self.server.requests], ['GET', 'POST'])
        body = __import__('json').loads(self.server.requests[-1].content)
        self.assertEqual(body['uri'], SPOTIFY_ITEM['uri'])
        self.assertEqual(body['service'], 'spop')
        self.assertEqual(self.server.requests[-1].url.path, '/api/v1/replaceAndPlay')

    def test_ambiguous_search_does_not_start_music(self):
        self.server.search_items = [SPOTIFY_ITEM, {**SPOTIFY_ITEM, 'uri': 'spotify:track:other'}]
        result = self.c.spotify_play('Get Lucky Daft Punk')
        self.assertEqual(result['reason'], 'ambiguous')
        self.assertEqual(len(self.server.requests), 1)

    def test_non_spotify_search_does_not_start_music(self):
        self.server.search_items = [{'service': 'mpd', 'type': 'song', 'uri': 'x', 'title': 'Get Lucky'}]
        self.assertFalse(self.c.spotify_play('Get Lucky')['accepted'])
        self.assertEqual(len(self.server.requests), 1)

    def test_request_error_is_propagated_without_faked_success(self):
        self.server.fail = True
        with self.assertRaises(VolumioUnavailable):
            self.c.command('play')

    def test_unexpected_url_rejected(self):
        for url in ('https://192.168.2.241', 'http://localhost/x',
                    'http://user:pass@localhost', 'http://localhost?secret=x'):
            with self.assertRaises(ValueError):
                VolumioClient(url)

    def test_browser_source(self):
        self.assertTrue(self.c.browse_sources()['spotify_visible'])


class VoiceTests(unittest.TestCase):
    def test_commands(self):
        for text, action in [
            ('Pause', 'pause'), ('Spiele weiter', 'play'), ('Musik aus', 'stop'),
            ('Nächster Song', 'next'), ('Vorheriger Titel', 'prev'),
            ('Lautstärke auf 30 Prozent', 'volume'), ('Mach leiser', 'volume_down'),
            ('Mach lauter', 'volume_up'), ('Was läuft gerade?', 'status'),
            ('Spiele Get Lucky von Daft Punk auf Spotify', 'spotify_play'),
            ('Suche Daft Punk auf Spotify', 'spotify_search'),
        ]:
            with self.subTest(text=text):
                self.assertEqual(music_agent.parse_voice(text).action, action)
        self.assertEqual(music_agent.parse_voice('Lautstärke auf 30 Prozent').value, 30)

    def test_normal_question_is_not_a_music_action(self):
        for q in ('Wie ist das Wetter?', 'Was bedeutet Pause?',
                  'Erkläre mir den Begriff Musik.', 'Was ist ein Lautstärkeregler?'):
            with self.subTest(q=q):
                self.assertIsNone(music_agent.parse_voice(q))

    def test_music_integration_message(self):
        server = MockVolumio()
        msg = music_agent.execute_intent(music_agent.Intent('status'), server.client())
        self.assertIn('Get Lucky', msg['answer'])


    def test_explicit_status_when_disabled_is_not_sent_to_general_llm(self):
        with patch.dict(os.environ, {'VOLUMIO_ENABLED': '0'}), \
             patch.object(music_agent, 'ollama_intent', side_effect=AssertionError('no LLM')):
            result = music_agent.handle_voice('Was läuft gerade?')
            self.assertIn('deaktiviert', result)
            self.assertIsNone(music_agent.handle_voice('Wie ist das Wetter?'))

    def test_status_from_audio_hook_skips_general_llm(self):
        with TemporaryDirectory() as td:
            a = Path(td) / 'app.py'
            p = Path(td) / 'pipeline.py'
            a.write_text('import pipeline\napp = FastAPI(title="x", version="0.4.1")\n')
            p.write_text('def generate_answer(user_text, history=None):\n'
                         '    """Use Ollama; the optional session history is bounded by the API layer."""\n'
                         '    return "FALSCH: allgemeines Ollama"\n')
            patch_server(a, p)
            namespace = {}
            with patch.object(music_agent, 'handle_voice', return_value='Volumio spielt gerade nichts ab.'):
                exec(compile(p.read_text(), str(p), 'exec'), namespace)
                self.assertEqual(namespace['generate_answer']('Was läuft gerade?'),
                                 'Volumio spielt gerade nichts ab.')

    def test_unknown_ollama_action_rejected(self):
        def handler(request):
            return httpx.Response(200, json={'message': {'content': '{"action":"run_shell","query":"rm -rf /"}'}})
        # httpx.Client is replaced by a transport-backed instance for this test.
        original = httpx.Client
        def client_factory(*args, **kwargs):
            return original(transport=httpx.MockTransport(handler))
        with patch.object(music_agent.httpx, 'Client', side_effect=client_factory):
            self.assertIsNone(music_agent.ollama_intent('Volumio bitte irgendwas machen'))


class APIIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.srv = MockVolumio()
        self.app = FastAPI()
        self.app.include_router(volumio_api.router)
        self.client = TestClient(self.app)
        self._env = patch.dict(os.environ, {'VOLUMIO_ENABLED': '1'})
        self._env.start()
        self._client = patch.object(volumio_api, '_client', self.srv.client)
        self._client.start()

    def tearDown(self):
        self._client.stop()
        self._env.stop()

    def test_rest_status_and_search(self):
        r = self.client.get('/api/volumio/status')
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()['title'], 'Get Lucky')
        search = self.client.get('/api/volumio/spotify/search?query=Daft%20Punk')
        self.assertEqual(search.status_code, 200)
        self.assertEqual(len(search.json()['candidates']), 1)

    def test_control(self):
        self.assertEqual(self.client.post('/api/volumio/control', json={'action':'next'}).status_code, 200)
        self.assertEqual(self.client.post('/api/volumio/control', json={'action':'volume', 'volume': 33}).status_code, 200)
        self.assertEqual(self.server_url_params()[-1], ('volume', '33'))

    def server_url_params(self):
        return [(r.url.params.get('cmd'), r.url.params.get('volume')) for r in self.srv.requests]

    def test_invalid_action_rejected_and_no_http_call(self):
        self.assertEqual(self.client.post('/api/volumio/control', json={'action':'reboot'}).status_code, 422)
        self.assertEqual(self.client.post('/api/volumio/control', json={'action':'volume', 'volume':101}).status_code, 422)
        self.assertEqual(len(self.srv.requests), 0)

    def test_offline_maps_to_502(self):
        self.srv.fail = True
        self.assertEqual(self.client.get('/api/volumio/status').status_code, 502)

    def test_disabled_maps_to_503(self):
        with patch.dict(os.environ, {'VOLUMIO_ENABLED': '0'}):
            self.assertEqual(self.client.get('/api/volumio/status').status_code, 503)

    def test_voice_endpoint(self):
        with patch.object(music_agent, 'VolumioClient', return_value=self.srv.client()):
            r = self.client.post('/api/volumio/voice', json={'text':'Nächster Song'})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json()['handled'])
        self.assertEqual(self.srv.requests[-1].url.params['cmd'], 'next')


class InstallerTests(unittest.TestCase):
    def test_patcher_is_idempotent_and_preserves_original_llm(self):
        with TemporaryDirectory() as td:
            a = Path(td)/'app.py'
            p = Path(td)/'pipeline.py'
            a.write_text('import pipeline\napp = FastAPI(title="x", version="0.4.1")\n')
            p.write_text('def generate_answer(user_text, history=None):\n'
                         '    """Use Ollama; the optional session history is bounded by the API layer."""\n'
                         '    return "original"\n')
            patch_server(a, p)
            once = (a.read_text(), p.read_text())
            patch_server(a, p)
            self.assertEqual(once, (a.read_text(), p.read_text()))
            self.assertIn('app.include_router(volumio_api.router)', a.read_text())
            self.assertIn('return "original"', p.read_text())
            self.assertIn('return music_answer', p.read_text())

    def test_failed_patch_writes_nothing(self):
        with TemporaryDirectory() as td:
            a = Path(td)/'app.py'
            p = Path(td)/'pipeline.py'
            a.write_text('import pipeline\napp = FastAPI()\n')
            p.write_text('def generate_answer(x):\n    return x\n')
            original = (a.read_text(), p.read_text())
            with self.assertRaises(RuntimeError):
                patch_server(a, p)
            self.assertEqual((a.read_text(), p.read_text()), original)


if __name__ == '__main__':
    unittest.main()
