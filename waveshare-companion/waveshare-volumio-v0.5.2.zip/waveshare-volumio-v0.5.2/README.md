# Waveshare Companion – Volumio Audio-Routing Hotfix v0.5.2

**Ziel:** Dein Ubuntu-Companion unter `192.168.2.207:8000` mit Volumio unter
`192.168.2.241` (Spotify-Plugin 4.5.0). Baut auf dem vorhandenen v0.5.1-Add-on
und Companion-Backend v0.4.1 auf. Die API von Waveshare bleibt unverändert.

## Warum der vorherige Test fehlschlug

`POST /api/volumio/voice` gab korrekt „Gerade läuft …“ zurück, aber ein WAV-Turn
wurde vom allgemeinen Ollama-Modell beantwortet. Damit war Volumio funktionsfähig,
aber der **laufende Audio-Worker** verwendete den richtigen Handler nicht.
Die frühere v0.5.1-Version prüfte lediglich einen optionalen Hook in
`pipeline.generate_answer()`, nicht seine Verwendung im tatsächlich laufenden
Job. Die genaue Ursache auf dem Ubuntu-Host (z. B. alter Uvicorn-Prozess oder
abweichende `pipeline.py`) lässt sich nur dort prüfen.

In **v0.5.2** erfolgt die Entscheidung nach Whisper **direkt in `app.work()`**:

1. `pipeline.transcribe(input.wav)` liefert Text.
2. `music_agent.handle_voice(transcript)` prüft den Sprachbefehl.
3. Bei einem Volumio-Befehl: Antwort von Volumio → `pipeline.synthesize()` → WAV.
4. Nur bei Rückgabe `None`: bisherige `pipeline.generate_answer()` an Ollama.

Das gilt für Sessions und Turns ohne Session. Der alte v0.5.1-Hook in
`pipeline.generate_answer()` wird entfernt, um doppelte Ausführung zu vermeiden.

## Installieren

```bash
cd /srv/ai/projects
wget -qO waveshare-volumio-v0.5.2.zip https://raw.githubusercontent.com/tyvda/ScriptBase/waveshare-companion-volumio-v0.5.2/waveshare-companion/waveshare-volumio-v0.5.2.zip
# Vor dem Auspacken die im Release genannte SHA-256 prüfen.
unzip -oq waveshare-volumio-v0.5.2.zip
bash waveshare-volumio-v0.5.2/install.sh /srv/ai/projects/companion-mvp/server
```

Der Installer erstellt ein Backup von `app.py`, `pipeline.py` und
`.env.companion`, prüft den **Job-Hook**, setzt die Volumio-Konfiguration und
startet `waveshare-companion.service` neu. Danach prüft er, dass der **laufende**
Server den neuen `/api/volumio/audio-routing`-Endpunkt bereitstellt und
`audio_worker_hook=true` meldet. Ist ein alter Prozess aktiv oder der Service
nicht startfähig, schlägt die Installation bewusst fehl und gibt eine Diagnose
statt einen falschen Erfolg auszugeben.

## Verifikation (ohne Änderung an der Wiedergabe)

```bash
curl -fsS http://127.0.0.1:8000/api/volumio/audio-routing
# erwartet: {"version":"0.5.2","audio_worker_hook":true,"volumio_enabled":true}
bash /srv/ai/projects/waveshare-volumio-v0.5.2/live_audio_smoke_test.sh
```

Der Audiotest fragt zunächst live die Worker-Version ab, testet das direkte
Volumio-Routing, spricht dann „Was läuft gerade?“ per Piper, lädt ein 16 kHz
WAV über `/api/turns` hoch, wartet auf `ready` und überprüft die Antwort und
das WAV. Bei Erfolg darf **keine** generische Ollama-Antwort erscheinen.

Nur lesende Diagnose:

```bash
bash /srv/ai/projects/waveshare-volumio-v0.5.2/diagnose_routing.sh
```

## Tests und Schutzmaßnahmen

`python3 -m unittest discover -s tests -v` prüft:
- Volumio HTTP-Kommandos und Spotify-Filter mit Mock-Server;
- deterministische Sprachbefehle und Nicht-Musik-Fragen;
- direkte WAV-Worker-Verzweigung (Volumio **ohne Ollama**), normaler Fallback;
- wiederholbare Installation ohne doppelte Code-Injektion;
- Abbruch ohne Code-Änderung bei unbekanntem Worker-Layout.

Echte Live-Integration muss auf deinem Ubuntu-Host getestet werden. Die
Waveshare-Audio-API und ihre 10-Sekunden-Grenze werden nicht verändert. Die
API ist ohne Token und darf nur im vertrauenswürdigen LAN erreichbar sein.
