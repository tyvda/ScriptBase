"""Patch the *running audio worker* instead of only wrapping Ollama.

The v0.5.1 voice route already worked, but the WAV job could still use the
unmodified pipeline.generate_answer(). Hook app.work() immediately after STT,
so a recognized Volumio command bypasses the generic LLM unconditionally.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys

MARKER = 'VOLUMIO_AUDIO_ROUTER_V052'

# Exact original v0.4.1 worker block; fail closed rather than silently installing
# a nonfunctional add-on if the upstream app layout has changed.
OLD_WORKER = (
    '        session_id = get_turn(turn_id).session_id\n'
    '        if session_id:\n'
    '            answer = pipeline.generate_answer(transcript, conversation_history(session_id, turn_id))\n'
    '        else:\n'
    '            answer = pipeline.generate_answer(transcript)\n'
)
NEW_WORKER = (
    '        # ' + MARKER + ': music commands bypass the general Ollama answer.\n'
    '        answer = music_agent.handle_voice(transcript)\n'
    '        if answer is None:\n'
    '            session_id = get_turn(turn_id).session_id\n'
    '            if session_id:\n'
    '                answer = pipeline.generate_answer(transcript, conversation_history(session_id, turn_id))\n'
    '            else:\n'
    '                answer = pipeline.generate_answer(transcript)\n'
)

# v0.5/v0.5.1 monkey-patch: deliberately remove it to avoid attempting music
# routing twice when a request legitimately falls through to normal Ollama.
OLD_PIPELINE_HOOK = (
    '    from music_agent import handle_voice\n'
    '    music_answer = handle_voice(user_text)\n'
    '    if music_answer is not None:\n'
    '        return music_answer\n'
)


def patch_server(app_path: Path, pipeline_path: Path) -> None:
    app = app_path.read_text(encoding='utf-8')
    pipeline = pipeline_path.read_text(encoding='utf-8')

    if 'import pipeline\n' not in app:
        raise RuntimeError('app.py: import pipeline fehlt; nichts verändert')
    if 'import music_agent\n' not in app:
        app = app.replace('import pipeline\n', 'import pipeline\nimport music_agent\n', 1)
    if 'import volumio_api\n' not in app:
        app = app.replace('import pipeline\n', 'import pipeline\nimport volumio_api\n', 1)

    if 'app.include_router(volumio_api.router)' not in app:
        pattern = r'(^app\s*=\s*FastAPI\([^\n]*\)\s*$)'
        if not re.search(pattern, app, re.M):
            raise RuntimeError('app.py: FastAPI-Anker fehlt; nichts verändert')
        app = re.sub(pattern, r'\1\napp.include_router(volumio_api.router)', app, count=1, flags=re.M)

    if MARKER not in app:
        if app.count(OLD_WORKER) != 1:
            raise RuntimeError('app.py: erwarteten Audio-Worker nicht gefunden; nichts verändert')
        app = app.replace(OLD_WORKER, NEW_WORKER, 1)
    elif app.count(MARKER) != 1 or 'answer = music_agent.handle_voice(transcript)' not in app:
        raise RuntimeError('app.py: inkonsistenter Volumio-Audio-Hook; nichts verändert')

    # Runtime marker enables distinguishing the current service from a stale
    # Uvicorn process, without exposing internal paths, credentials, or settings.
    if 'def volumio_audio_route_info(' not in app:
        app += (
            '\n\n@app.get("/api/volumio/audio-routing")\n'
            'def volumio_audio_route_info():\n'
            '    return {"version": "0.5.2", "audio_worker_hook": True,\n'
            '            "volumio_enabled": os.getenv("VOLUMIO_ENABLED", "0").casefold() '
            'in ("1", "true", "yes")}\n'
        )

    if OLD_PIPELINE_HOOK in pipeline:
        pipeline = pipeline.replace(OLD_PIPELINE_HOOK, '', 1)

    # Validate all changes before either file is written.
    compile(app, str(app_path), 'exec')
    compile(pipeline, str(pipeline_path), 'exec')
    app_path.write_text(app, encoding='utf-8')
    pipeline_path.write_text(pipeline, encoding='utf-8')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: python install_patch.py <companion-mvp/server>')
    base = Path(sys.argv[1])
    patch_server(base/'app.py', base/'pipeline.py')
