#!/usr/bin/env bash
# Non-destructive diagnosis of Volumio speech routing on Ubuntu.
set -u
TARGET="${1:-/srv/ai/projects/companion-mvp/server}"
BASE="${2:-http://127.0.0.1:8000}"
printf '\n== Local files ==\n'
for p in app.py pipeline.py music_agent.py volumio_api.py .env.companion; do
    [[ -f "$TARGET/$p" ]] && echo "OK: $p" || echo "MISSING: $p"
done
printf '\n== Volumio settings in file ==\n'
if [[ -f "$TARGET/.env.companion" ]]; then
    grep -E '^VOLUMIO_(ENABLED|URL|TIMEOUT)=' "$TARGET/.env.companion" || true
fi
printf '\n== Source hook ==\n'
grep -n 'VOLUMIO_AUDIO_ROUTER_V053\|answer = music_agent.handle_voice' "$TARGET/app.py" 2>/dev/null || true
printf '\n== systemd ==\n'
systemctl --user show waveshare-companion -p ActiveState -p MainPID --no-pager 2>/dev/null || true
printf '\n== Backend /health ==\n'
curl -sS -i --max-time 5 "$BASE/health" | head -c 400; printf '\n'
printf '\n== Volumio REST status, read-only ==\n'
curl -sS -i --max-time 10 "$BASE/api/volumio/status" | head -c 750; printf '\n'
printf '\n== Volumio voice routing, read-only ==\n'
curl -sS -i --max-time 12 -H 'Content-Type: application/json' -d '{"text":"Was läuft gerade?"}' "$BASE/api/volumio/voice" | head -c 850; printf '\n'

printf '
== Aktiver Worker (muss v0.5.3 liefern) ==
'
curl -sS -i --max-time 8 "$BASE/api/volumio/audio-routing" | head -c 500; printf '
'
printf '
== Port 8000 = Uvicorn process ==
'
ss -ltnp '( sport = :8000 )' 2>/dev/null || true
