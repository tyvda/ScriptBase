#!/usr/bin/env bash
# Safe in-place upgrade of the existing user systemd Companion backend.
set -Eeuo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
TARGET="${1:-/srv/ai/projects/companion-mvp/server}"
SERVICE='waveshare-companion.service'
if [[ ! -f "$TARGET/app.py" || ! -f "$TARGET/pipeline.py" || ! -x "$TARGET/.venv/bin/python" ]]; then
  echo "Backend or its Python venv missing: $TARGET" >&2; exit 2
fi
if ! command -v systemctl >/dev/null || ! systemctl --user list-unit-files "$SERVICE" --no-legend 2>/dev/null | grep -q waveshare-companion; then
  echo "User service $SERVICE not installed; no automatic restart possible" >&2; exit 2
fi
BACKUP="$TARGET/.volumio-backup-$(date -u +%Y%m%d-%H%M%S)-$$"
mkdir -m 700 -p "$BACKUP"
FILES=(app.py pipeline.py music_agent.py volumio_api.py volumio_controller.py .env.companion)
for name in "${FILES[@]}"; do
  if [[ -f "$TARGET/$name" ]]; then cp -p -- "$TARGET/$name" "$BACKUP/$name"; else touch "$BACKUP/$name.missing"; fi
done
ROLLBACK_REQUIRED=1
rollback() {
  rc=$?
  trap - ERR EXIT
  if (( ROLLBACK_REQUIRED )); then
    printf 'Upgrade fehlgeschlagen (rc=%s). Stelle Backup wieder her: %s\n' "$rc" "$BACKUP" >&2
    for name in "${FILES[@]}"; do
      if [[ -e "$BACKUP/$name.missing" ]]; then rm -f -- "$TARGET/$name"; else cp -p -- "$BACKUP/$name" "$TARGET/$name"; fi
    done
    systemctl --user restart "$SERVICE" 2>/dev/null || true
  fi
  exit "$rc"
}
trap rollback ERR EXIT
for name in music_agent.py volumio_api.py volumio_controller.py; do
  install -m 0644 "$SCRIPT_DIR/server/$name" "$TARGET/$name"
done
python3 "$SCRIPT_DIR/install_patch.py" "$TARGET"
"$TARGET/.venv/bin/python" -m py_compile "$TARGET/app.py" "$TARGET/pipeline.py" "$TARGET/volumio_controller.py" "$TARGET/volumio_api.py" "$TARGET/music_agent.py"
ENVFILE="$TARGET/.env.companion"
if [[ ! -f "$ENVFILE" ]]; then printf '' > "$ENVFILE"; fi
"$TARGET/.venv/bin/python" - "$ENVFILE" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1]); lines = p.read_text(encoding='utf-8').splitlines()
for key, val in [('VOLUMIO_ENABLED','1'),('VOLUMIO_URL','http://192.168.2.241'),('VOLUMIO_TIMEOUT','5')]:
    lines = [line for line in lines if not line.startswith(key+'=')]
    lines.append(key+'='+val)
p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
PY
# Verify the worker's actual interpretation, not just the independent REST route.
"$TARGET/.venv/bin/python" - "$TARGET" <<'PY'
import sys, ast
from pathlib import Path
sys.path.insert(0, sys.argv[1])
import music_agent
assert music_agent.parse_voice('Was läuft gerade?').action == 'status'
src = Path(sys.argv[1], 'app.py').read_text()
work = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name=='work')
code = ast.get_source_segment(src, work)
assert 'VOLUMIO_AUDIO_ROUTER_V053' in code and 'music_agent.handle_voice(transcript)' in code
print('Static worker check OK')
PY
systemctl --user restart "$SERVICE"
loaded=0
for i in $(seq 1 "${VOLUMIO_INSTALL_CHECK_RETRIES:-15}"); do
  if curl -fsS --max-time 3 http://127.0.0.1:8000/api/volumio/audio-routing 2>/dev/null \
    | "$TARGET/.venv/bin/python" -c 'import json,sys; x=json.load(sys.stdin); assert x["version"]=="0.5.3" and x["audio_worker_hook"] and x["volumio_enabled"]' 2>/dev/null; then
    loaded=1; break
  fi
  sleep 1
done
if (( ! loaded )); then
  echo 'Live-Worker weiterhin nicht v0.5.3: journalctl --user -u waveshare-companion -n 50 --no-pager' >&2
  false
fi
ROLLBACK_REQUIRED=0
trap - ERR EXIT
printf 'Volumio Audio-Worker v0.5.3 installiert, geladen und konfiguriert. Backup: %s\n' "$BACKUP"
