"""Conservative AST-guided patch for Companion WAV worker, v0.5.3.

Finds a semantic checkpoint (transcript committed to 'thinking') instead of
matching an exact source-code string. Never replaces or truncates existing
pipeline behavior, and refuses unknown layouts before writing anything.
"""
from __future__ import annotations

import ast
from pathlib import Path
import re
import sys

MARKER = 'VOLUMIO_AUDIO_ROUTER_V053'
MUSIC_HOOK = '''{indent}# VOLUMIO_AUDIO_ROUTER_V053: intercept music directly in the WAV job.
{indent}music_answer = music_agent.handle_voice(transcript)
{indent}if music_answer is not None:
{indent}    if not update_if_active(turn_id, answer=music_answer, state="speaking"):
{indent}        return
{indent}    pipeline.synthesize(music_answer, folder / "answer.wav")
{indent}    update_if_active(turn_id, state="ready")
{indent}    return
'''


def _call(node, name):
    return isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == name


def _attr_call(node, module, name):
    return (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == module and node.func.attr == name)


def _checkpoint(node):
    """Recognize the state transition after STT regardless of original formatting."""
    if not isinstance(node, ast.If) or node.orelse:
        return False
    test = node.test
    if not isinstance(test, ast.UnaryOp) or not isinstance(test.op, ast.Not):
        return False
    call = test.operand
    if not _call(call, 'update_if_active'):
        return False
    names = {kw.arg: kw.value for kw in call.keywords}
    return (isinstance(names.get('state'), ast.Constant)
            and names['state'].value == 'thinking'
            and isinstance(names.get('transcript'), ast.Name)
            and names['transcript'].id == 'transcript'
            and len(node.body) == 1
            and isinstance(node.body[0], ast.Return))


def patch_server(app_path: Path, pipeline_path: Path) -> None:
    app = app_path.read_text(encoding='utf-8')
    pipeline = pipeline_path.read_text(encoding='utf-8')
    tree = ast.parse(app, str(app_path))
    funcs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'work']
    if len(funcs) != 1:
        raise RuntimeError(f'app.py: work()-Funktion nicht eindeutig gefunden ({len(funcs)}); unverändert')
    worker = funcs[0]
    work_source = ast.get_source_segment(app, worker) or ''
    if MARKER in work_source:
        if work_source.count(MARKER) != 1 or 'music_agent.handle_voice(transcript)' not in work_source:
            raise RuntimeError('app.py: vorhandener Audio-Hook ist inkonsistent; unverändert')
    else:
        # Refuse an already modified worker instead of injecting music calls twice.
        if 'VOLUMIO_AUDIO_ROUTER_V052' in work_source or 'music_agent.handle_voice(transcript)' in work_source:
            raise RuntimeError('app.py: anderer direkter Volumio-Worker-Hook gefunden; unverändert')
        checkpoints = [n for n in ast.walk(worker) if _checkpoint(n)]
        transcribes = [n for n in ast.walk(worker) if _attr_call(n, 'pipeline', 'transcribe')]
        synths = [n for n in ast.walk(worker) if _attr_call(n, 'pipeline', 'synthesize')]
        if (len(checkpoints), len(transcribes), len(synths)) != (1, 1, 1):
            raise RuntimeError('app.py: Workerstruktur weicht ab: '
                               f'thinking_check={len(checkpoints)} '
                               f'transcribe={len(transcribes)} synthesize={len(synths)}. '
                               'Keine Dateien verändert; bitte diesen Fehler und die work()-Funktion melden.')
        checkpoint = checkpoints[0]
        if not (transcribes[0].lineno < checkpoint.lineno < synths[0].lineno):
            raise RuntimeError('app.py: Verarbeitungsschritte in unerwarteter Reihenfolge; unverändert')
        if not any(isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'folder' for t in n.targets)
                   for n in ast.walk(worker)):
            raise RuntimeError('app.py: Audio-Zielvariable folder fehlt; unverändert')
        lines = app.splitlines(keepends=True)
        origin = lines[checkpoint.lineno - 1]
        indent = origin[:len(origin)-len(origin.lstrip(' \t'))]
        if not indent:
            raise RuntimeError('app.py: unerwartete Einrückung am Checkpoint; unverändert')
        lines.insert(checkpoint.end_lineno, MUSIC_HOOK.format(indent=indent))
        app = ''.join(lines)

    if 'import music_agent' not in app or 'import volumio_api' not in app:
        tree = ast.parse(app, str(app_path))
        imports = [n for n in tree.body if isinstance(n, ast.Import)
                   and any(a.name == 'pipeline' for a in n.names)]
        if len(imports) != 1:
            raise RuntimeError('app.py: import pipeline ist nicht eindeutig; unverändert')
        injected = ''.join('import ' + name + '\n' for name in ('music_agent', 'volumio_api')
                           if 'import '+name not in app)
        lines = app.splitlines(keepends=True)
        lines.insert(imports[0].end_lineno, injected)
        app = ''.join(lines)

    if 'app.include_router(volumio_api.router)' not in app:
        tree = ast.parse(app, str(app_path))
        assignments = [n for n in tree.body if isinstance(n, ast.Assign)
                       and any(isinstance(t, ast.Name) and t.id == 'app' for t in n.targets)
                       and _call(n.value, 'FastAPI')]
        if len(assignments) != 1:
            raise RuntimeError('app.py: FastAPI-App nicht eindeutig; unverändert')
        lines = app.splitlines(keepends=True)
        lines.insert(assignments[0].end_lineno, 'app.include_router(volumio_api.router)\n')
        app = ''.join(lines)

    if 'def volumio_audio_route_info(' not in app:
        app += ('\n\n@app.get("/api/volumio/audio-routing")\n'
                'def volumio_audio_route_info():\n'
                '    return {"version": "0.5.3", "audio_worker_hook": True,\n'
                '            "volumio_enabled": os.getenv("VOLUMIO_ENABLED", "0").lower() '
                'in ("1", "true", "yes")}\n')
    else:
        # Existing 0.5.2 endpoint is not enough proof that 0.5.3 is loaded.
        app = re.sub(r'(def volumio_audio_route_info\(\):\s*\n\s*return \{"version": )"0\.5\.2"',
                     r'\g<1>"0.5.3"', app)
        if '"version": "0.5.3"' not in app:
            raise RuntimeError('app.py: bestehender Debug-Endpunkt lässt sich nicht eindeutig aktualisieren')

    compiled = compile(app, str(app_path), 'exec')
    compile(pipeline, str(pipeline_path), 'exec')
    if not compiled or app.count(MARKER) != 1:
        raise RuntimeError('app.py: Worker-Patch konnte nicht eindeutig verifiziert werden')
    # Last operation after all structural/compile checks; pipeline remains unchanged.
    app_path.write_text(app, encoding='utf-8')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: python install_patch.py <companion-mvp/server>')
    base = Path(sys.argv[1])
    patch_server(base/'app.py', base/'pipeline.py')
