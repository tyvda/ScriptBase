#!/usr/bin/env python3
"""Read-only integration probe for an Ubuntu server and a live Volumio.

--allow-play optionally tests the next-track command. Do not use while music
needs to remain uninterrupted. Requires only Python stdlib.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request


def get(base: str, path: str):
    req = urllib.request.Request(base + path, headers={'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode('utf-8', 'replace')[:300]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--backend', default='http://127.0.0.1:8000')
    parser.add_argument('--query', default='Daft Punk')
    parser.add_argument('--allow-play', action='store_true', help='Actually skip current track (mutates Volumio)')
    args = parser.parse_args()
    base = args.backend.rstrip('/')
    checks = [('/health', 200), ('/api/volumio/status', 200),
              ('/api/volumio/sources', 200),
              ('/api/volumio/spotify/search?query=' + urllib.parse.quote(args.query), 200)]
    failed = False
    for path, expected in checks:
        try:
            status, body = get(base, path)
            print('\n', path, 'HTTP', status)
            print(json.dumps(body, indent=2, ensure_ascii=False)[:1500])
            if status != expected:
                failed = True
        except Exception as exc:
            failed = True
            print(path, 'ERROR', type(exc).__name__, str(exc)[:140])
    if args.allow_play:
        print('\n[WARNUNG] Ändere Wiedergabe: NEXT')
        data = json.dumps({'action':'next'}).encode('utf-8')
        req = urllib.request.Request(base + '/api/volumio/control',
            data=data, headers={'Content-Type':'application/json'}, method='POST')
        try:
            with urllib.request.urlopen(req, timeout=8) as r:
                print('NEXT HTTP', r.status, r.read().decode('utf-8', 'replace')[:300])
        except Exception as exc:
            failed = True
            print('NEXT ERROR', type(exc).__name__, str(exc)[:160])
    print('\nLive-Probe:', 'FAIL' if failed else 'PASS (nur Erreichbarkeit/Lesen getestet)')
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
