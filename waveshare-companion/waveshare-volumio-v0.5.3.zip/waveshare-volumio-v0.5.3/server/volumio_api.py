"""Optional Volumio REST API endpoints mounted into the existing FastAPI server."""
from __future__ import annotations

import os
from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from volumio_controller import VolumioClient, VolumioError
from music_agent import Intent, execute_intent, handle_voice

router = APIRouter(prefix='/api/volumio', tags=['Volumio'])


class ControlRequest(BaseModel):
    action: Literal['play', 'pause', 'stop', 'next', 'prev', 'toggle',
                    'volume', 'volume_up', 'volume_down', 'mute', 'unmute', 'status']
    volume: int | None = Field(default=None, ge=0, le=100)


class SpotifyPlayRequest(BaseModel):
    query: str = Field(min_length=3, max_length=120)


class VoiceRequest(BaseModel):
    text: str = Field(min_length=1, max_length=300)


def _enabled():
    if os.getenv('VOLUMIO_ENABLED', '0').casefold() not in ('1', 'true', 'yes'):
        raise HTTPException(status_code=503, detail='Volumio-Integration deaktiviert')


def _client() -> VolumioClient:
    return VolumioClient(timeout=float(os.getenv('VOLUMIO_TIMEOUT', '5')))


def _run(fn):
    try:
        return fn()
    except VolumioError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get('/status')
def status():
    _enabled()
    return _run(lambda: _client().state())


@router.get('/sources')
def sources():
    _enabled()
    return _run(lambda: _client().browse_sources())


@router.get('/spotify/search')
def spotify_search(query: str = Query(min_length=3, max_length=120), limit: int = Query(default=8, ge=1, le=20)):
    _enabled()
    return _run(lambda: _client().spotify_search(query, limit))


@router.post('/spotify/play')
def spotify_play(payload: SpotifyPlayRequest):
    _enabled()
    return _run(lambda: _client().spotify_play(payload.query))


@router.post('/control')
def control(payload: ControlRequest):
    _enabled()
    return _run(lambda: execute_intent(
        Intent(action=payload.action, value=payload.volume), _client()))


@router.post('/voice')
def voice(payload: VoiceRequest):
    _enabled()
    try:
        result = handle_voice(payload.text)
    except Exception as exc:
        raise HTTPException(status_code=502, detail='Fehler bei der Sprachverarbeitung') from exc
    return {'handled': result is not None, 'answer': result}
