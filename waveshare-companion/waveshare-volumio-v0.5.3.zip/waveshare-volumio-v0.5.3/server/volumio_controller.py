"""Small, strict Volumio REST client for the Waveshare Companion (Volumio 4 / spop).

Only sends traffic to VOLUMIO_URL. HTTP response=success is *acknowledgement*,
not proof that playback actually started; the state must be checked separately.
"""
from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher
import os
import re
import unicodedata
from typing import Any

import httpx

SPOTIFY_SERVICES = frozenset({'spop', 'spotify'})
PLAYABLE_TYPES = frozenset({'song', 'track'})
COMMANDS = frozenset({'play', 'pause', 'stop', 'next', 'prev', 'toggle'})


class VolumioError(Exception):
    pass


class VolumioUnavailable(VolumioError):
    pass


@dataclass(frozen=True)
class Track:
    title: str
    artist: str
    album: str
    uri: str
    service: str
    type: str
    albumart: str = ''

    def as_dict(self) -> dict[str, str]:
        return self.__dict__.copy()


def _normalize(s: str) -> str:
    s = unicodedata.normalize('NFKD', s.casefold())
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return ' '.join(re.findall(r'\w+', s))


def _score(query: str, track: Track) -> float:
    q = _normalize(query)
    t = _normalize(f'{track.title} {track.artist}')
    if not q or not t:
        return 0.0
    qw, tw = set(q.split()), set(t.split())
    overlap = len(qw & tw) / max(1, len(qw))
    match = SequenceMatcher(None, q, t).ratio()
    if q in t:
        return 1.0
    return 0.7 * overlap + 0.3 * match


class VolumioClient:
    def __init__(self, base_url: str | None = None, *, transport: httpx.BaseTransport | None = None, timeout: float = 5.0):
        base_url = (base_url or os.getenv('VOLUMIO_URL', 'http://192.168.2.241')).rstrip('/')
        url = httpx.URL(base_url)
        if url.scheme != 'http' or not url.host or url.userinfo or url.path not in ('', '/') or url.query or url.fragment:
            raise ValueError('VOLUMIO_URL must be an unadorned http://host[:port] URL')
        self.base_url = base_url
        self._transport = transport
        self.timeout = timeout

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return self._request('GET', path, params=params)

    def _post(self, path: str, data: dict[str, Any]) -> Any:
        return self._request('POST', path, json=data)

    def _request(self, method: str, path: str, **kwargs) -> Any:
        try:
            with httpx.Client(timeout=self.timeout, transport=self._transport, trust_env=False,
                              follow_redirects=False) as client:
                response = client.request(method, self.base_url + path, **kwargs)
                response.raise_for_status()
                try:
                    result = response.json()
                except ValueError as exc:
                    raise VolumioError(f'Volumio lieferte kein JSON für {path}') from exc
                if isinstance(result, dict) and (
                    result.get('response') in ('error', 'failure') or result.get('success') is False
                ):
                    raise VolumioError('Volumio hat den Befehl abgelehnt')
                return result
        except (httpx.TimeoutException, httpx.NetworkError, httpx.ProtocolError, httpx.HTTPStatusError) as exc:
            raise VolumioUnavailable(f'Volumio {self.base_url} nicht erreichbar oder HTTP-Fehler: {type(exc).__name__}') from exc

    def state(self) -> dict[str, Any]:
        state = self._get('/api/v1/getState')
        if not isinstance(state, dict):
            raise VolumioError('Ungültiger Playerstatus')
        keys = ('status', 'title', 'artist', 'album', 'albumart', 'service', 'volume', 'mute', 'uri', 'duration', 'seek')
        return {key: state.get(key) for key in keys}

    def command(self, action: str) -> dict[str, Any]:
        if action not in COMMANDS:
            raise ValueError('Unzulässiger Playerbefehl')
        ack = self._get('/api/v1/commands/', {'cmd': action})
        return {'accepted': True, 'action': action, 'ack': ack}

    def set_volume(self, volume: int) -> dict[str, Any]:
        if isinstance(volume, bool) or not isinstance(volume, int) or not 0 <= volume <= 100:
            raise ValueError('Lautstärke muss zwischen 0 und 100 liegen')
        ack = self._get('/api/v1/commands/', {'cmd': 'volume', 'volume': volume})
        return {'accepted': True, 'volume': volume, 'ack': ack}

    def change_volume(self, delta: int) -> dict[str, Any]:
        state = self.state()
        if state['volume'] is None:
            raise VolumioError('Lautstärke lässt sich nicht abfragen')
        try:
            volume = int(state['volume'])
        except (TypeError, ValueError) as exc:
            raise VolumioError('Ungültiger Lautstärkewert') from exc
        return self.set_volume(max(0, min(100, volume + delta)))

    def mute(self, enabled: bool) -> dict[str, Any]:
        ack = self._get('/api/v1/commands/', {'cmd': 'volume', 'volume': 'mute' if enabled else 'unmute'})
        return {'accepted': True, 'mute': enabled, 'ack': ack}

    def browse_sources(self) -> dict[str, Any]:
        data = self._get('/api/v1/browse')
        nav = data.get('navigation', {}) if isinstance(data, dict) else {}
        sources = [item for item in nav.get('lists', []) if isinstance(item, dict)]
        return {'spotify_visible': any('spotify' in str(item.get('name', '')).casefold() or item.get('uri') == 'spotify' for item in sources),
                'sources': [{'name': x.get('name'), 'uri': x.get('uri')} for x in sources[:50]]}

    def spotify_search(self, query: str, limit: int = 8) -> dict[str, Any]:
        if not isinstance(query, str) or not 3 <= len(query.strip()) <= 120:
            raise ValueError('Suchbegriff muss 3 bis 120 Zeichen enthalten')
        if not 1 <= limit <= 20:
            raise ValueError('limit muss 1 bis 20 sein')
        data = self._get('/api/v1/search', {'query': query.strip()})
        nav = data.get('navigation', {}) if isinstance(data, dict) else {}
        lists = nav.get('lists', []) if isinstance(nav, dict) else []
        if not isinstance(lists, list):
            raise VolumioError('Unerwartetes Suchergebnisformat')
        results: list[Track] = []
        for group in lists:
            items = group.get('items', []) if isinstance(group, dict) else []
            if not isinstance(items, list):
                continue
            for item in items:
                if not isinstance(item, dict):
                    continue
                uri = item.get('uri') or ''
                service = str(item.get('service') or '').casefold()
                # Only returned Spotify items, never local files or other services.
                if service not in SPOTIFY_SERVICES or not isinstance(uri, str) or not uri.startswith('spotify:'):
                    continue
                results.append(Track(
                    title=str(item.get('title') or item.get('name') or ''),
                    artist=str(item.get('artist') or ''), album=str(item.get('album') or ''),
                    uri=uri, service=service, type=str(item.get('type') or '').casefold(),
                    albumart=str(item.get('albumart') or ''),
                ))
        results.sort(key=lambda x: _score(query, x), reverse=True)
        return {'query': query.strip(), 'source': 'volumio_rest_search',
                'supported': bool(results),
                'candidates': [x.as_dict() for x in results[:limit]],
                'message': ('Spotify-Treffer gefunden.' if results else
                            'Volumio lieferte keine Spotify-Treffer. Prüfe Plugin-Anmeldung und die Spotify-Suche in Volumio.')}

    def spotify_play(self, query: str) -> dict[str, Any]:
        result = self.spotify_search(query, limit=15)
        candidates = [Track(**item) for item in result['candidates'] if item['type'] in PLAYABLE_TYPES]
        if not candidates:
            return {'accepted': False, 'reason': 'no_tracks', 'message':
                    'Keine abspielbaren Spotify-Titel gefunden. Prüfe die Spotify-Anmeldung.',
                    'candidates': result['candidates'][:5]}
        ranked = sorted(((t, _score(query, t)) for t in candidates), key=lambda x: x[1], reverse=True)
        best, score = ranked[0]
        runner = ranked[1][1] if len(ranked) > 1 else 0.0
        # Don't replace an existing queue for ambiguous or poor matches.
        if score < .55 or (len(ranked) > 1 and score - runner < .10):
            return {'accepted': False, 'reason': 'ambiguous', 'message':
                    'Kein eindeutiger Treffer. Bitte nenne Titel und Interpret genauer.',
                    'candidates': [t.as_dict() for t, _ in ranked[:5]]}
        item = best.as_dict()
        # Volumio REST accepts single-item payloads without the {item,list,index} wrapper.
        ack = self._post('/api/v1/replaceAndPlay', item)
        return {'accepted': True, 'action': 'spotify_play', 'track': item, 'ack': ack,
                'message': f'Wiedergabe von {best.title} von {best.artist} angefordert.'}
