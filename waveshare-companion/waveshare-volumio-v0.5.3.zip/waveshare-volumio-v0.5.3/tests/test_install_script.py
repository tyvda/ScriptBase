"""End-to-end installer tests with fake systemd/curl; no network or service changes."""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

from test_volumio_integration import make_base_files, BASE


class InstallationTests(unittest.TestCase):
    def _fake_services(self, path: Path, valid: bool) -> Path:
        path.mkdir()
        systemctl = path / 'systemctl'
        systemctl.write_text('#!/bin/sh\n'
                             'case "$*" in\n'
                             '  *list-unit-files*) echo "waveshare-companion.service enabled";;\n'
                             '  *restart*) echo restart >> "$FAKE_SERVICE_LOG";;\n'
                             'esac\n')
        curl = path / 'curl'
        if valid:
            curl.write_text('#!/bin/sh\necho \'{"version":"0.5.3","audio_worker_hook":true,"volumio_enabled":true}\'\n')
        else:
            curl.write_text('#!/bin/sh\necho \'{"version":"0.5.2","audio_worker_hook":true,"volumio_enabled":true}\'\n')
        systemctl.chmod(0o755)
        curl.chmod(0o755)
        return path

    def _run(self, valid=True, corrupt=False):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            target = root / 'server'
            target.mkdir()
            app, pipeline = make_base_files(target)
            if corrupt:
                app.write_text(app.read_text().replace('state="thinking"', 'state="waiting"'))
            original = app.read_text()
            (target / '.env.companion').write_text('OLLAMA_MODEL=gemma3:4b\nVOLUMIO_ENABLED=0\n')
            (target / '.venv/bin').mkdir(parents=True)
            (target / '.venv/bin/python').write_text('#!/bin/sh\nexec '+sys.executable+' \"$@\"\n')
            (target / '.venv/bin/python').chmod(0o755)
            helpers = self._fake_services(root / 'bin', valid=valid)
            env = dict(os.environ, PATH=str(helpers) + ':' + os.environ['PATH'],
                       FAKE_SERVICE_LOG=str(root / 'service.log'), VOLUMIO_INSTALL_CHECK_RETRIES="2")
            result = subprocess.run(['bash', str(BASE/'install.sh'), str(target)],
                                    env=env, capture_output=True, text=True, timeout=30)
            return result, original, app.read_text(), (target / '.env.companion').read_text(), \
                (root/'service.log').read_text() if (root/'service.log').exists() else ''

    def test_installs_worker_and_restarts_service(self):
        result, _, app, env, log = self._run()
        self.assertEqual(result.returncode, 0, result.stdout+'\n'+result.stderr)
        self.assertIn('VOLUMIO_AUDIO_ROUTER_V053', app)
        self.assertIn('VOLUMIO_ENABLED=1', env)
        self.assertIn('OLLAMA_MODEL=gemma3:4b', env)
        self.assertIn('restart', log)

    def test_rolls_back_if_worker_layout_is_unknown(self):
        result, original, app, env, _ = self._run(corrupt=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(original, app)
        self.assertIn('VOLUMIO_ENABLED=0', env)

    def test_rolls_back_if_service_does_not_load_new_worker(self):
        result, original, app, env, log = self._run(valid=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(original, app)
        self.assertIn('VOLUMIO_ENABLED=0', env)
        self.assertIn('restart', log)


if __name__ == '__main__':
    unittest.main()
