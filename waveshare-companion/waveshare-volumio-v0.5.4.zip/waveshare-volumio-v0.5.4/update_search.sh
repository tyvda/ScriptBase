#!/usr/bin/env bash
# Upgrade only the Spotify track selector; do not touch app.py, pipeline.py or .env.
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
TARGET="${1:-/srv/ai/projects/companion-mvp/server}"
SERVICE="waveshare-companion.service"
NEW="$HERE/server/volumio_controller.py"
OLD="$TARGET/volumio_controller.py"
PYTHON="$TARGET/.venv/bin/python"

[[ -f "$OLD" && -x "$PYTHON" ]] || { echo 'Backend oder Volumio-Controller nicht gefunden' >&2; exit 2; }
command -v systemctl >/dev/null || { echo 'systemctl fehlt' >&2; exit 2; }
"$PYTHON" -m py_compile "$NEW"
BACKUP="$TARGET/volumio_controller.py.backup-$(date -u +%Y%m%d-%H%M%S)-$$"
cp -p "$OLD" "$BACKUP"
TEMP="$TARGET/.volumio_controller.py.tmp-$$"
RESTORE=1
rollback() {
  local rc=$?
  trap - ERR INT TERM
  if [[ "$RESTORE" == 1 ]]; then
    echo "Upgrade fehlgeschlagen, Rollback: $BACKUP" >&2
    cp -p "$BACKUP" "$OLD"
    systemctl --user restart "$SERVICE" >/dev/null 2>&1 || true
  fi
  rm -f "$TEMP"
  exit "$rc"
}
trap rollback ERR INT TERM
install -m 0644 "$NEW" "$TEMP"
mv -f "$TEMP" "$OLD"
"$PYTHON" - "$TARGET" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
from volumio_controller import Track, _score, _recording_key
x=Track('Get Lucky','Daft Punk','Random Access Memories','spotify:track:one','spop','song')
y=Track('Get Lucky','Daft Punk','Deluxe Edition','spotify:track:two','spop','song')
assert _recording_key(x)==_recording_key(y)
assert _score('Get Lucky von Daft Punk',x)>0.95
print('Controller-Selbsttest erfolgreich')
PY
systemctl --user restart "$SERVICE"
for _ in {1..20}; do
  if systemctl --user is-active --quiet "$SERVICE" && curl -fsS --max-time 3 http://127.0.0.1:8000/health >/dev/null; then
    RESTORE=0
    trap - ERR INT TERM
    echo "Spotify-Trefferlogik v0.5.4 installiert; Backup: $BACKUP"
    exit 0
  fi
  sleep 1
done
false
