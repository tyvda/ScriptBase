#!/usr/bin/env python3
"""Read-only: inspect Spotify search matches and their match confidence."""
import argparse
import json
from pathlib import Path
import sys
import urllib.parse
import urllib.request


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('query', help='Titel und ggf. Interpret, z. B. "Get Lucky von Daft Punk"')
    parser.add_argument('--backend', default='http://127.0.0.1:8000')
    parser.add_argument('--server-dir', default='/srv/ai/projects/companion-mvp/server')
    args = parser.parse_args()
    sys.path.insert(0, args.server_dir)
    from volumio_controller import Track, _score, _recording_key
    url = args.backend.rstrip('/') + '/api/volumio/spotify/search?' + urllib.parse.urlencode(
        {'query': args.query, 'limit': 20})
    with urllib.request.urlopen(url, timeout=15) as response:
        data = json.load(response)
    print('Volumio-Suche:', data.get('query'), '| Treffer:', len(data.get('candidates') or []))
    groups = {}
    for d in data.get('candidates') or []:
        try:
            t = Track(**d)
            score = _score(args.query, t)
            key = _recording_key(t)
            if key not in groups:
                groups[key] = [t, score, 0]
            groups[key][2] += 1
        except (TypeError, ValueError) as exc:
            print('Unerwartetes Suchformat:', str(exc)[:100])
    for i, (t, score, copies) in enumerate(sorted(groups.values(),key=lambda x:x[1],reverse=True),1):
        print(f'{i:2}. score={score:.3f}, releases={copies}, title={t.title!r}, artist={t.artist!r}, album={t.album!r}, service={t.service}')
    if not groups:
        print('Keine Spotify-Titel aus der Volumio-REST-Suche. Plugin/Anmeldung prüfen.')
    else:
        print('Nur Suche; keine Wiedergabe verändert.')


if __name__=='__main__':
    main()
