"""Install-only tests: no Volumio hardware, systemd or outside network access."""
from pathlib import Path
from tempfile import TemporaryDirectory
import os
import shutil
import subprocess
import sys
import unittest

from test_volumio_integration import BASE


class SearchUpdateTests(unittest.TestCase):
    def run_update(self, *, service_healthy=True):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            target = root / 'server'
            (target / '.venv/bin').mkdir(parents=True)
            (target / '.venv/bin/python').write_text('#!/bin/sh\nexec '+sys.executable+' "$@"\n')
            (target / '.venv/bin/python').chmod(0o755)
            old = target / 'volumio_controller.py'
            old.write_text('ORIGINAL = 1\n', encoding='utf-8')
            (target / 'app.py').write_text('DO_NOT_TOUCH = True\n', encoding='utf-8')
            (target / 'pipeline.py').write_text('DO_NOT_TOUCH = True\n', encoding='utf-8')
            bin_dir = root / 'bin'
            bin_dir.mkdir()
            (bin_dir / 'systemctl').write_text('#!/bin/sh\n'
                                                  'if [ "$2" = "is-active" ] && [ "$SEARCH_TEST_HEALTH" = "0" ]; then exit 1; fi\n'
                                                  'exit 0\n')
            (bin_dir / 'curl').write_text('#!/bin/sh\necho \'{"ok":true}\'\n')
            for cmd in ('systemctl', 'curl'):
                (bin_dir / cmd).chmod(0o755)
            env = {**os.environ, 'PATH': str(bin_dir) + ':' + os.environ['PATH'],
                   'SEARCH_TEST_HEALTH': '1' if service_healthy else '0'}
            # Reduce retry duration for rollback testing using fake sleep.
            (bin_dir / 'sleep').write_text('#!/bin/sh\nexit 0\n')
            (bin_dir / 'sleep').chmod(0o755)
            result = subprocess.run(['bash', str(BASE/'update_search.sh'), str(target)],
                                    env=env, capture_output=True, text=True, timeout=30)
            current = old.read_text()
            return result, current, (target / 'app.py').read_text(), (target / 'pipeline.py').read_text()

    def test_updates_only_controller_and_keeps_worker(self):
        result, controller, app, pipeline = self.run_update()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('_recording_key', controller)
        self.assertIn('DO_NOT_TOUCH', app)
        self.assertIn('DO_NOT_TOUCH', pipeline)

    def test_unhealthy_service_rolls_back_controller(self):
        result, controller, _, _ = self.run_update(service_healthy=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(controller, 'ORIGINAL = 1\n')


if __name__ == '__main__':
    unittest.main()
