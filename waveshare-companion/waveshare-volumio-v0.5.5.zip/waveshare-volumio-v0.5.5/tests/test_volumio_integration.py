"""Integration tests using a simulated Volumio HTTP server (no LAN access needed)."""
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace, ModuleType
import unittest
from unittest.mock import patch

import httpx
from fastapi import FastAPI
from fastapi.testclient import TestClient

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / 'server'))
sys.path.insert(0, str(BASE))

import music_agent
import volumio_api
from volumio_controller import VolumioClient, VolumioError, VolumioUnavailable
from install_patch import patch_server


SPOTIFY_ITEM = {'service': 'spop', 'type': 'song', 'title': 'Get Lucky',
                'artist': 'Daft Punk', 'album': 'Random Access Memories',
                'uri': 'spotify:track:2Foc5Q5nqNiosCNqttzHof'}


class MockVolumio:
    def __init__(self):
        self.requests = []
        self.state = {'status': 'play', 'title': 'Get Lucky', 'artist': 'Daft Punk',
                      'volume': 42, 'service': 'spop'}
        self.search_items = [SPOTIFY_ITEM, {'service': 'mpd', 'type': 'song',
                           'title': 'Local', 'uri': 'music-library/x'}]
        self.fail = False

    def handle(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        if self.fail:
            return httpx.Response(503, json={'detail': 'offline'})
        path = request.url.path
        if path.endswith('/getState'):
            return httpx.Response(200, json=self.state)
        if path.endswith('/commands/'):
            return httpx.Response(200, json={'response': 'success'})
        if path.endswith('/search'):
            return httpx.Response(200, json={'navigation': {'lists': [{'items': self.search_items}]}})
        if path.endswith('/browse'):
            return httpx.Response(200, json={'navigation': {'lists': [{'name':'Spotify', 'uri':'spotify'}]}})
        if path.endswith('/replaceAndPlay'):
            return httpx.Response(200, json={'response': 'success'})
        return httpx.Response(404, json={'detail': 'unknown'})

    def client(self):
        return VolumioClient('http://192.168.2.241', transport=httpx.MockTransport(self.handle))


class VolumioHTTPTests(unittest.TestCase):
    def setUp(self):
        self.server = MockVolumio()
        self.c = self.server.client()

    def test_read_state(self):
        state = self.c.state()
        self.assertEqual(state['title'], 'Get Lucky')
        self.assertEqual(str(self.server.requests[-1].url), 'http://192.168.2.241/api/v1/getState')

    def test_player_commands_whitelist_and_parameter_encoding(self):
        for action in ('play', 'pause', 'stop', 'prev', 'next', 'toggle'):
            self.assertTrue(self.c.command(action)['accepted'])
        self.assertEqual([r.url.params['cmd'] for r in self.server.requests],
                         ['play', 'pause', 'stop', 'prev', 'next', 'toggle'])
        with self.assertRaises(ValueError):
            self.c.command('reboot')
        self.assertEqual(len(self.server.requests), 6)

    def test_volume_absolute_relative_and_bounds(self):
        self.c.set_volume(30)
        self.assertEqual(self.server.requests[-1].url.params['volume'], '30')
        self.assertEqual(self.c.change_volume(-10)['volume'], 32)
        self.assertEqual(self.c.change_volume(100)['volume'], 100)
        for invalid in (-1, 101, True):
            with self.assertRaises(ValueError):
                self.c.set_volume(invalid)

    def test_mute(self):
        self.c.mute(True)
        self.assertEqual(self.server.requests[-1].url.params['volume'], 'mute')
        self.c.mute(False)
        self.assertEqual(self.server.requests[-1].url.params['volume'], 'unmute')

    def test_spotify_search_filters_local_tracks(self):
        result = self.c.spotify_search('Get Lucky Daft Punk')
        self.assertEqual(len(result['candidates']), 1)
        self.assertEqual(result['candidates'][0]['service'], 'spop')
        self.assertEqual(self.server.requests[-1].url.params['query'], 'Get Lucky Daft Punk')

    def test_play_from_real_search_result_not_invented_uri(self):
        result = self.c.spotify_play('Get Lucky Daft Punk')
        self.assertTrue(result['accepted'])
        self.assertEqual([r.method for r in self.server.requests], ['GET', 'POST'])
        body = __import__('json').loads(self.server.requests[-1].content)
        self.assertEqual(body['uri'], SPOTIFY_ITEM['uri'])
        self.assertEqual(body['service'], 'spop')
        self.assertEqual(self.server.requests[-1].url.path, '/api/v1/replaceAndPlay')

    def test_duplicate_release_same_title_artist_is_playable(self):
        self.server.search_items = [SPOTIFY_ITEM, {**SPOTIFY_ITEM,
            'uri': 'spotify:track:other', 'album': 'Deluxe Edition'}]
        result = self.c.spotify_play('Get Lucky von Daft Punk')
        self.assertTrue(result['accepted'])
        self.assertEqual(result['duplicate_releases_ignored'], 1)
        self.assertEqual(len(self.server.requests), 2)
        self.assertEqual(self.server.requests[-1].url.path, '/api/v1/replaceAndPlay')

    def test_multiple_artists_same_title_stays_ambiguous(self):
        self.server.search_items = [SPOTIFY_ITEM, {**SPOTIFY_ITEM,
            'uri': 'spotify:track:cover', 'artist': 'Karaoke Stars'}]
        result = self.c.spotify_play('Get Lucky')
        self.assertEqual(result['reason'], 'ambiguous')
        self.assertEqual(len(self.server.requests), 1)
        self.assertEqual(len(result['candidates']), 2)

    def test_explicit_artist_disambiguates_matching_titles(self):
        self.server.search_items = [{**SPOTIFY_ITEM, 'uri': 'spotify:track:cover',
                                     'artist': 'Daft Punk Tribute'}, SPOTIFY_ITEM]
        result = self.c.spotify_play('Get Lucky von Daft Punk')
        self.assertTrue(result['accepted'])
        self.assertEqual(result['track']['artist'], 'Daft Punk')

    def test_exact_artist_cannot_be_replaced_by_tribute(self):
        self.server.search_items = [{**SPOTIFY_ITEM, 'artist': 'Daft Punk Tribute'}]
        result = self.c.spotify_play('Get Lucky von Daft Punk')
        self.assertFalse(result['accepted'])
        self.assertEqual(len(self.server.requests), 1)

    def test_artist_only_request_is_not_an_arbitrary_song(self):
        self.server.search_items = [SPOTIFY_ITEM]
        result = self.c.spotify_play('Daft Punk')
        self.assertFalse(result['accepted'])
        self.assertEqual(result['reason'], 'low_confidence')
        self.assertEqual(len(self.server.requests), 1)

    def test_distinct_titles_no_random_selection(self):
        self.server.search_items = [SPOTIFY_ITEM, {**SPOTIFY_ITEM,
            'uri': 'spotify:track:second', 'title': 'Get Lucky Tonight'}]
        result = self.c.spotify_play('Get Lucky')
        self.assertTrue(result['accepted'])
        self.assertEqual(result['track']['title'], 'Get Lucky')

    def test_no_matching_song_rejected(self):
        self.server.search_items = [SPOTIFY_ITEM]
        result = self.c.spotify_play('Bohemian Rhapsody von Queen')
        self.assertFalse(result['accepted'])
        self.assertEqual(len(self.server.requests), 1)

    def test_non_spotify_search_does_not_start_music(self):
        self.server.search_items = [{'service': 'mpd', 'type': 'song', 'uri': 'x', 'title': 'Get Lucky'}]
        self.assertFalse(self.c.spotify_play('Get Lucky')['accepted'])
        self.assertEqual(len(self.server.requests), 1)

    def test_request_error_is_propagated_without_faked_success(self):
        self.server.fail = True
        with self.assertRaises(VolumioUnavailable):
            self.c.command('play')

    def test_unexpected_url_rejected(self):
        for url in ('https://192.168.2.241', 'http://localhost/x',
                    'http://user:pass@localhost', 'http://localhost?secret=x'):
            with self.assertRaises(ValueError):
                VolumioClient(url)

    def test_browser_source(self):
        self.assertTrue(self.c.browse_sources()['spotify_visible'])


# The following Spotify candidates were reproduced from the real Volumio 4.5.0
# spop result supplied during the integration test on 2026-11-23.
DAFT_PUNK_RELEASES = [
    {'title': 'Get Lucky (Daft Punk Remix) (feat. Pharrell Williams & Nile Rodgers)',
     'artist': 'Daft Punk', 'album': '', 'uri': 'spotify:track:remix-preview',
     'type': 'song', 'service': 'spop'},
    {'title': 'Get Lucky (Radio Edit) [feat. Pharrell Williams and Nile Rodgers]',
     'artist': 'Daft Punk', 'album': '', 'uri': 'spotify:track:radio-preview',
     'type': 'song', 'service': 'spop'},
    {'title': 'Get Lucky (feat. Pharrell Williams and Nile Rodgers)',
     'artist': 'Daft Punk', 'album': 'Random Access Memories',
     'uri': 'spotify:track:69kOkLUCkxIZYexIgSG8rq', 'type': 'song', 'service': 'spop'},
    {'title': 'Get Lucky (Radio Edit) [feat. Pharrell Williams and Nile Rodgers]',
     'artist': 'Daft Punk', 'album': 'Get Lucky (Radio Edit) [feat. Pharrell Williams and Nile Rodgers]',
     'uri': 'spotify:track:2Foc5Q5nqNiosCNqttzHof', 'type': 'song', 'service': 'spop'},
    {'title': 'Get Lucky - Daft Punk Remix', 'artist': 'Daft Punk',
     'album': 'Get Lucky (Daft Punk Remix) (feat. Pharrell Williams & Nile Rodgers)',
     'uri': 'spotify:track:78NwNb2BPO7OKDYYRWB1WT', 'type': 'song', 'service': 'spop'},
    {'title': 'Get Lucky', 'artist': 'Ali Brustofski', 'album': 'Get Lucky',
     'uri': 'spotify:track:4m0dHFvHgmmdoTvYb7Enm8', 'type': 'song', 'service': 'spop'},
    {'title': 'Get Lucky', 'artist': 'Janaína', 'album': '',
     'uri': 'spotify:track:cover2', 'type': 'song', 'service': 'spop'},
]


class RealSpotifyRankingTests(unittest.TestCase):
    def setUp(self):
        self.server = MockVolumio()
        self.server.search_items = DAFT_PUNK_RELEASES.copy()
        self.client = self.server.client()

    def test_default_request_chooses_actual_studio_recording(self):
        out = self.client.spotify_play('Get Lucky von Daft Punk')
        self.assertTrue(out['accepted'], out)
        self.assertEqual(out['track']['uri'], 'spotify:track:69kOkLUCkxIZYexIgSG8rq')
        self.assertEqual(self.server.requests[-1].url.path, '/api/v1/replaceAndPlay')

    def test_explicit_remix_chooses_remix_instead_of_album(self):
        self.server.search_items = self.server.search_items[2:]  # no preview listing
        out = self.client.spotify_play('Get Lucky (Daft Punk Remix) (feat. Pharrell Williams & Nile Rodgers)')
        self.assertTrue(out['accepted'], out)
        self.assertEqual(out['track']['uri'], 'spotify:track:78NwNb2BPO7OKDYYRWB1WT')

    def test_explicit_radio_edit_chooses_radio_edit(self):
        out = self.client.spotify_play('Get Lucky (Radio Edit) von Daft Punk')
        self.assertTrue(out['accepted'], out)
        self.assertIn('Radio Edit', out['track']['title'])

    def test_covers_still_ambiguous_for_unnamed_artist(self):
        out = self.client.spotify_play('Get Lucky')
        self.assertFalse(out['accepted'], out)
        self.assertEqual(out['reason'], 'ambiguous')
        self.assertEqual([req.method for req in self.server.requests], ['GET'])

    def test_nonmatching_requested_remix_does_not_fall_back_to_original(self):
        self.server.search_items = DAFT_PUNK_RELEASES[2:3]
        out = self.client.spotify_play('Get Lucky (Daft Punk Remix) (feat. Pharrell Williams & Nile Rodgers)')
        self.assertFalse(out['accepted'], out)
        self.assertEqual([req.method for req in self.server.requests], ['GET'])

    def test_similar_featuring_labels_collapse_into_one_base_recording(self):
        from volumio_controller import Track, _recording_key
        base = DAFT_PUNK_RELEASES[2]
        alternate = {**base, 'title': 'Get Lucky (feat. Pharrell Williams & Nile Rodgers)',
                     'uri': 'spotify:track:other-release', 'album': 'Compilation'}
        self.assertEqual(_recording_key(Track(**base)), _recording_key(Track(**alternate)))

    def test_artist_suffix_without_von_is_also_supported(self):
        out = self.client.spotify_play('Get Lucky Daft Punk')
        self.assertTrue(out['accepted'], out)
        self.assertEqual(out['track']['uri'], 'spotify:track:69kOkLUCkxIZYexIgSG8rq')


class VoiceTests(unittest.TestCase):
    def test_commands(self):
        for text, action in [
            ('Pause', 'pause'), ('Spiele weiter', 'play'), ('Musik aus', 'stop'),
            ('Nächster Song', 'next'), ('Vorheriger Titel', 'prev'),
            ('Lautstärke auf 30 Prozent', 'volume'), ('Mach leiser', 'volume_down'),
            ('Mach lauter', 'volume_up'), ('Was läuft gerade?', 'status'),
            ('Spiele Get Lucky von Daft Punk auf Spotify', 'spotify_play'),
            ('Suche Daft Punk auf Spotify', 'spotify_search'),
        ]:
            with self.subTest(text=text):
                self.assertEqual(music_agent.parse_voice(text).action, action)
        self.assertEqual(music_agent.parse_voice('Lautstärke auf 30 Prozent').value, 30)

    def test_normal_question_is_not_a_music_action(self):
        for q in ('Wie ist das Wetter?', 'Was bedeutet Pause?',
                  'Erkläre mir den Begriff Musik.', 'Was ist ein Lautstärkeregler?'):
            with self.subTest(q=q):
                self.assertIsNone(music_agent.parse_voice(q))

    def test_music_integration_message(self):
        server = MockVolumio()
        msg = music_agent.execute_intent(music_agent.Intent('status'), server.client())
        self.assertIn('Get Lucky', msg['answer'])


    def test_explicit_status_when_disabled_is_not_sent_to_general_llm(self):
        with patch.dict(os.environ, {'VOLUMIO_ENABLED': '0'}), \
             patch.object(music_agent, 'ollama_intent', side_effect=AssertionError('no LLM')):
            result = music_agent.handle_voice('Was läuft gerade?')
            self.assertIn('deaktiviert', result)
            self.assertIsNone(music_agent.handle_voice('Wie ist das Wetter?'))

    def test_direct_audio_worker_routes_music_before_ollama(self):
        with TemporaryDirectory() as td:
            a, p = make_base_files(Path(td))
            patch_server(a, p)
            calls = []
            mock_pipeline = ModuleType('pipeline')
            mock_pipeline.transcribe = lambda _: 'Was läuft gerade?'
            mock_pipeline.generate_answer = lambda *args: calls.append('OLLAMA') or 'WRONG LLM'
            mock_pipeline.synthesize = lambda answer, _: calls.append(('PIPER', answer))
            fake_app = SimpleNamespace(include_router=lambda router: None, get=lambda _: lambda fn: fn)
            state = SimpleNamespace(session_id=None)
            names = {'FastAPI': lambda **kw: fake_app, 'work_dir': Path(td),
                     'get_turn': lambda _: state,
                     'update_if_active': lambda _id, **fields: calls.append(fields) or True,
                     'conversation_history': lambda *args: []}
            with patch.dict(sys.modules, {'pipeline': mock_pipeline}), \
                 patch.object(music_agent, 'handle_voice', return_value='Gerade läuft Modeselektor.'):
                exec(compile(a.read_text(), str(a), 'exec'), names)
                names['work']('job1')
            self.assertNotIn('OLLAMA', calls)
            self.assertIn(('PIPER', 'Gerade läuft Modeselektor.'), calls)
            self.assertTrue(any(x == {'answer': 'Gerade läuft Modeselektor.', 'state': 'speaking'} for x in calls))

    def test_normal_audio_worker_still_calls_ollama(self):
        with TemporaryDirectory() as td:
            a, p = make_base_files(Path(td))
            patch_server(a, p)
            calls = []
            mock_pipeline = ModuleType('pipeline')
            mock_pipeline.transcribe = lambda _: 'Wie ist das Wetter?'
            mock_pipeline.generate_answer = lambda *args: calls.append('OLLAMA') or 'Heute ist es sonnig.'
            mock_pipeline.synthesize = lambda answer, _: calls.append(('PIPER', answer))
            fake_app = SimpleNamespace(include_router=lambda router: None, get=lambda _: lambda fn: fn)
            names = {'FastAPI': lambda **kw: fake_app, 'work_dir': Path(td),
                     'get_turn': lambda _: SimpleNamespace(session_id=None),
                     'update_if_active': lambda _id, **fields: True,
                     'conversation_history': lambda *args: []}
            with patch.dict(sys.modules, {'pipeline': mock_pipeline}), \
                 patch.object(music_agent, 'handle_voice', return_value=None):
                exec(compile(a.read_text(), str(a), 'exec'), names)
                names['work']('job2')
            self.assertIn('OLLAMA', calls)
            self.assertIn(('PIPER', 'Heute ist es sonnig.'), calls)

    def test_unknown_ollama_action_rejected(self):
        def handler(request):
            return httpx.Response(200, json={'message': {'content': '{"action":"run_shell","query":"rm -rf /"}'}})
        # httpx.Client is replaced by a transport-backed instance for this test.
        original = httpx.Client
        def client_factory(*args, **kwargs):
            return original(transport=httpx.MockTransport(handler))
        with patch.object(music_agent.httpx, 'Client', side_effect=client_factory):
            self.assertIsNone(music_agent.ollama_intent('Volumio bitte irgendwas machen'))


class APIIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.srv = MockVolumio()
        self.app = FastAPI()
        self.app.include_router(volumio_api.router)
        self.client = TestClient(self.app)
        self._env = patch.dict(os.environ, {'VOLUMIO_ENABLED': '1'})
        self._env.start()
        self._client = patch.object(volumio_api, '_client', self.srv.client)
        self._client.start()

    def tearDown(self):
        self._client.stop()
        self._env.stop()

    def test_rest_status_and_search(self):
        r = self.client.get('/api/volumio/status')
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()['title'], 'Get Lucky')
        search = self.client.get('/api/volumio/spotify/search?query=Daft%20Punk')
        self.assertEqual(search.status_code, 200)
        self.assertEqual(len(search.json()['candidates']), 1)

    def test_control(self):
        self.assertEqual(self.client.post('/api/volumio/control', json={'action':'next'}).status_code, 200)
        self.assertEqual(self.client.post('/api/volumio/control', json={'action':'volume', 'volume': 33}).status_code, 200)
        self.assertEqual(self.server_url_params()[-1], ('volume', '33'))

    def server_url_params(self):
        return [(r.url.params.get('cmd'), r.url.params.get('volume')) for r in self.srv.requests]

    def test_invalid_action_rejected_and_no_http_call(self):
        self.assertEqual(self.client.post('/api/volumio/control', json={'action':'reboot'}).status_code, 422)
        self.assertEqual(self.client.post('/api/volumio/control', json={'action':'volume', 'volume':101}).status_code, 422)
        self.assertEqual(len(self.srv.requests), 0)

    def test_offline_maps_to_502(self):
        self.srv.fail = True
        self.assertEqual(self.client.get('/api/volumio/status').status_code, 502)

    def test_disabled_maps_to_503(self):
        with patch.dict(os.environ, {'VOLUMIO_ENABLED': '0'}):
            self.assertEqual(self.client.get('/api/volumio/status').status_code, 503)

    def test_voice_endpoint(self):
        with patch.object(music_agent, 'VolumioClient', return_value=self.srv.client()):
            r = self.client.post('/api/volumio/voice', json={'text':'Nächster Song'})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json()['handled'])
        self.assertEqual(self.srv.requests[-1].url.params['cmd'], 'next')


def make_base_files(folder: Path):
    """Small fixture mirroring the v0.4.1 app.work() call graph."""
    app_path = folder / 'app.py'
    pipeline_path = folder / 'pipeline.py'
    app_path.write_text('''import pipeline
import os
app = FastAPI(title="x", version="0.4.1")
def work(turn_id):
    folder = work_dir / turn_id
    if True:
        if not update_if_active(turn_id, state="transcribing"):
            return
        transcript = pipeline.transcribe(folder / "input.wav")
        if not transcript:
            raise RuntimeError("no speech")
        if not update_if_active(turn_id, transcript=transcript, state="thinking"):
            return
        session_id = get_turn(turn_id).session_id
        if session_id:
            answer = pipeline.generate_answer(transcript, conversation_history(session_id, turn_id))
        else:
            answer = pipeline.generate_answer(transcript)
        if not update_if_active(turn_id, answer=answer, state="speaking"):
            return
        pipeline.synthesize(answer, folder / "answer.wav")
        update_if_active(turn_id, state="ready")
''', encoding="utf-8")
    pipeline_path.write_text('def generate_answer(user_text, history=None):\n'
                             '    """Use Ollama; the optional session history is bounded by the API layer."""\n'
                             '    from music_agent import handle_voice\n'
                             '    music_answer = handle_voice(user_text)\n'
                             '    if music_answer is not None:\n'
                             '        return music_answer\n'
                             '    return "original"\n')
    return app_path, pipeline_path


class InstallerTests(unittest.TestCase):
    def test_patcher_is_idempotent_and_moves_voice_to_worker(self):
        with TemporaryDirectory() as td:
            a, p = make_base_files(Path(td))
            patch_server(a, p)
            once = (a.read_text(), p.read_text())
            patch_server(a, p)
            self.assertEqual(once, (a.read_text(), p.read_text()))
            self.assertIn('app.include_router(volumio_api.router)', a.read_text())
            self.assertIn('VOLUMIO_AUDIO_ROUTER_V053', a.read_text())
            self.assertIn('music_answer = music_agent.handle_voice(transcript)', a.read_text())
            self.assertIn('from music_agent import handle_voice', p.read_text())
            self.assertIn('return "original"', p.read_text())

    def test_patcher_rejects_unknown_worker_without_changing_files(self):
        with TemporaryDirectory() as td:
            a, p = make_base_files(Path(td))
            a.write_text(a.read_text().replace('state="thinking"',
                                                'state="waiting"'))
            before = (a.read_text(), p.read_text())
            with self.assertRaises(RuntimeError):
                patch_server(a, p)
            self.assertEqual(before, (a.read_text(), p.read_text()))

    def test_source_formatting_changes_do_not_break_injection(self):
        with TemporaryDirectory() as td:
            a, p = make_base_files(Path(td))
            a.write_text(a.read_text().replace(
                'answer = pipeline.generate_answer(transcript, conversation_history(session_id, turn_id))',
                'answer = pipeline.generate_answer(\n                transcript,\n                conversation_history(session_id, turn_id)\n            )',
            ).replace('        session_id = get_turn(turn_id).session_id',
                      '        # Custom code before conversation routing\n        session_id = get_turn(turn_id).session_id'))
            patch_server(a, p)
            self.assertEqual(a.read_text().count('VOLUMIO_AUDIO_ROUTER_V053'), 1)
            self.assertIn('music_answer = music_agent.handle_voice(transcript)', a.read_text())

    def test_patcher_does_not_modify_on_invalid_syntax(self):
        with TemporaryDirectory() as td:
            a, p = make_base_files(Path(td))
            a.write_text(a.read_text() + '\ndef broken(:')
            before = (a.read_text(), p.read_text())
            with self.assertRaises(SyntaxError):
                patch_server(a, p)
            self.assertEqual(before, (a.read_text(), p.read_text()))
