#!/usr/bin/env bash
# Addon for existing Waveshare Companion v0.4.1. No sudo needed for user service.
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-/srv/ai/projects/companion-mvp/server}"
if [[ ! -f "$TARGET/app.py" || ! -f "$TARGET/pipeline.py" ]]; then
  echo "Companion-Backend nicht gefunden: $TARGET" >&2; exit 2
fi
BACKUP="$TARGET/.volumio-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp "$TARGET/app.py" "$TARGET/pipeline.py" "$BACKUP/"
if [[ -f "$TARGET/.env.companion" ]]; then cp "$TARGET/.env.companion" "$BACKUP/"; fi
rollback() {
  echo "Installation fehlgeschlagen – stelle app.py und pipeline.py wieder her" >&2
  cp "$BACKUP/app.py" "$TARGET/app.py"
  cp "$BACKUP/pipeline.py" "$TARGET/pipeline.py"
  [[ ! -f "$BACKUP/.env.companion" ]] || cp "$BACKUP/.env.companion" "$TARGET/.env.companion"
}
trap rollback ERR
cp "$SCRIPT_DIR/server/volumio_controller.py" "$SCRIPT_DIR/server/music_agent.py" "$SCRIPT_DIR/server/volumio_api.py" "$TARGET/"
python3 "$SCRIPT_DIR/install_patch.py" "$TARGET"
python3 -m py_compile "$TARGET/app.py" "$TARGET/pipeline.py" "$TARGET/volumio_controller.py" "$TARGET/music_agent.py" "$TARGET/volumio_api.py"
ENVFILE="$TARGET/.env.companion"
touch "$ENVFILE"
# Leave other existing Ollama/Piper/Whisper settings intact. Do not duplicate keys.
grep -q '^VOLUMIO_URL=' "$ENVFILE" || printf '%s\n' 'VOLUMIO_URL=http://192.168.2.241' >> "$ENVFILE"
grep -q '^VOLUMIO_ENABLED=' "$ENVFILE" || printf '%s\n' 'VOLUMIO_ENABLED=1' >> "$ENVFILE"
grep -q '^VOLUMIO_TIMEOUT=' "$ENVFILE" || printf '%s\n' 'VOLUMIO_TIMEOUT=5' >> "$ENVFILE"
trap - ERR
if systemctl --user list-unit-files waveshare-companion.service --no-legend 2>/dev/null | grep -q waveshare-companion; then
  systemctl --user restart waveshare-companion.service
  echo 'systemd waveshare-companion neugestartet'
else
  echo 'Kein systemd User-Service gefunden – starte den bestehenden Uvicorn-Prozess manuell neu.'
fi
echo "Volumio-Modul installiert. Backup: $BACKUP"
