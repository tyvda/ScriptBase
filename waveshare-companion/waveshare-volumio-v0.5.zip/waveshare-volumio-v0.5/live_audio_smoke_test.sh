#!/usr/bin/env bash
# Read-only real E2E: Piper -> Whisper -> Volumio state -> Piper -> WAV.
set -Eeuo pipefail
SERVER_DIR="${1:-/srv/ai/projects/companion-mvp/server}"
BASE_URL="${2:-http://127.0.0.1:8000}"
PY="$SERVER_DIR/.venv/bin/python"
[[ -x "$PY" && -f "$SERVER_DIR/.env.companion" ]] || { echo 'Fehlendes Backend / .env.companion' >&2; exit 2; }
set -a
# shellcheck source=/dev/null
source "$SERVER_DIR/.env.companion"
set +a
for x in ffmpeg ffprobe curl; do command -v "$x" >/dev/null || { echo "$x fehlt" >&2; exit 2; }; done
TMP="$(mktemp -d)"
trap 'rm -rf -- "$TMP"' EXIT
"$PY" -m piper -m "$PIPER_MODEL" -f "$TMP/question0.wav" -- 'Was läuft gerade?'
ffmpeg -hide_banner -nostdin -v error -y -i "$TMP/question0.wav" -t 10 -ac 1 -ar 16000 -c:a pcm_s16le "$TMP/question.wav"
ID="$(curl -fsS --max-time 30 -H 'Content-Type: audio/wav' --data-binary "@$TMP/question.wav" "$BASE_URL/api/turns?plain=1")"
[[ "$ID" =~ ^[0-9a-fA-F-]{36}$ ]] || { echo 'Ungueltige Job-ID' >&2; exit 1; }
for i in {1..180}; do
  STATE="$(curl -fsS --max-time 8 "$BASE_URL/api/turns/$ID/state")"
  [[ "$STATE" != failed && "$STATE" != cancelled ]] || { curl -sS "$BASE_URL/api/turns/$ID"; exit 1; }
  if [[ "$STATE" == ready ]]; then break; fi
  sleep 1
done
[[ "${STATE:-}" == ready ]] || { echo 'Backend-Timeout' >&2; exit 1; }
curl -fsS "$BASE_URL/api/turns/$ID" | "$PY" -c 'import json,sys; s=json.load(sys.stdin); print("Whisper:",s["transcript"]); print("Antwort:",s["answer"]); assert s["transcript"] and s["answer"]'
curl -fsS -o "$TMP/answer.wav" "$BASE_URL/api/turns/$ID/audio.wav"
ffprobe -v error -select_streams a:0 -show_entries stream=sample_rate,channels -of default=noprint_wrappers=1 "$TMP/answer.wav"
echo 'E2E abgeschlossen. Wenn Antwort nur einen Volumio-Netzwerkfehler nennt, bitte LAN-Verbindung pruefen.'
