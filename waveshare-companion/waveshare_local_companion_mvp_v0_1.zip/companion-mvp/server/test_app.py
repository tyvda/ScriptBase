"""Run with: python -m unittest -v test_app  (from server/)"""

import io
import os
import unittest
from unittest.mock import patch
import wave

from fastapi.testclient import TestClient

import app


def make_wav(frames=1600, rate=16000):
    output = io.BytesIO()
    with wave.open(output, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        wav.writeframes(b"\0\0" * frames)
    return output.getvalue()


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app.app)
        self.headers = {"Authorization": "Bearer test-secret", "Content-Type": "audio/wav"}
        self.patch_token = patch.dict(os.environ, {"COMPANION_TOKEN": "test-secret"})
        self.patch_token.start()

    def tearDown(self):
        self.patch_token.stop()

    def test_auth_and_format_validation(self):
        self.assertEqual(self.client.post("/api/turns", content=make_wav()).status_code, 401)
        invalid = self.client.post("/api/turns", content=make_wav(rate=44100), headers=self.headers)
        self.assertEqual(invalid.status_code, 422)
        oversized = self.client.post("/api/turns", content=b"x" * 700000, headers=self.headers)
        self.assertEqual(oversized.status_code, 413)
        malformed = self.client.post("/api/turns", content=b"abc", headers=self.headers)
        self.assertEqual(malformed.status_code, 422)

    def test_async_turn_and_audio_download(self):
        fake_result = make_wav()

        def fake_synthesize(text, target):
            target.write_bytes(fake_result)

        with patch.object(app.pipeline, "transcribe", return_value="Hallo"), \
             patch.object(app.pipeline, "generate_answer", return_value="Guten Tag"), \
             patch.object(app.pipeline, "synthesize", side_effect=fake_synthesize):
            upload = self.client.post("/api/turns?plain=1", content=make_wav(), headers=self.headers)
            self.assertEqual(upload.status_code, 202)
            turn_id = upload.text
            # Wait only for the mocked background worker to finish.
            app._pool.submit(lambda: None).result(timeout=2)
            status = self.client.get(f"/api/turns/{turn_id}", headers=self.headers).json()
            self.assertEqual(status["state"], "ready")
            self.assertEqual(status["transcript"], "Hallo")
            audio = self.client.get(f"/api/turns/{turn_id}/audio.wav", headers=self.headers)
            self.assertEqual(audio.status_code, 200)
            self.assertEqual(audio.content, fake_result)

    def test_unknown_turn(self):
        result = self.client.get("/api/turns/not-found/state", headers=self.headers)
        self.assertEqual(result.status_code, 404)


if __name__ == "__main__":
    unittest.main()
